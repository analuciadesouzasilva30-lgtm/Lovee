//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cx7CgpK8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/media"],
		preloads: ["/assets/index-DDICFk9k.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DDICFk9k.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DgrCdW2E.js"]
	}
} });
//#endregion
export { tsrStartManifest };
