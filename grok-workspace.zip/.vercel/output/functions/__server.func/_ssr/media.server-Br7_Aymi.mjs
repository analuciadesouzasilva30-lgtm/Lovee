import { t as getSql } from "./db-B9adYO-Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/media.server-Br7_Aymi.js
var AUDIO = /* @__PURE__ */ new Set([
	"audio/mpeg",
	"audio/mp3",
	"audio/mp4",
	"audio/aac",
	"audio/ogg",
	"audio/wav",
	"audio/x-wav",
	"audio/webm"
]);
var IMAGES = /* @__PURE__ */ new Set([
	"image/jpeg",
	"image/png",
	"image/webp"
]);
async function readMedia(key) {
	if (key !== "music" && key !== "photo1" && key !== "photo2") return null;
	const row = (await (await getSql()).query("select mime, data from sky_media where key = $1", [key]))[0];
	if (!row?.data) return null;
	if (!(key === "music" ? AUDIO : IMAGES).has(row.mime)) return null;
	return {
		mime: row.mime,
		bytes: Uint8Array.from(Buffer.from(row.data, "base64"))
	};
}
//#endregion
export { readMedia };
