import { timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/guard.server-C61AuRsF.js
/** Shared writing key for the hidden panel. Not exported to the client. */
function passwordMatches(password) {
	const given = Buffer.from(password);
	const expected = Buffer.from("love123");
	if (given.length !== expected.length) return false;
	return timingSafeEqual(given, expected);
}
//#endregion
export { passwordMatches };
