import { o as __toESM } from "../_runtime.mjs";
import { a as heartPoints, s as signature, t as STAR_POS } from "./content-DHthi_kq.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Moon, i as Play, n as Square, o as BookOpen, r as Sparkles } from "../_libs/lucide-react.mjs";
import { a as saveMedia, i as getSky, n as Route$1, o as saveSky, r as checkAdmin } from "./router-Ct7IfhhF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-0bPZ18Z-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BASE = 430;
var LEFT = [
	{
		x: 18,
		w: 54,
		h: 130,
		seed: 1,
		antenna: false
	},
	{
		x: 78,
		w: 42,
		h: 190,
		seed: 2,
		antenna: false
	},
	{
		x: 126,
		w: 70,
		h: 150,
		seed: 3,
		antenna: false
	},
	{
		x: 202,
		w: 26,
		h: 230,
		seed: 4,
		antenna: true
	},
	{
		x: 234,
		w: 84,
		h: 110,
		seed: 5,
		antenna: false
	},
	{
		x: 324,
		w: 40,
		h: 78,
		seed: 6,
		antenna: false
	}
];
var RIGHT = [
	{
		x: 850,
		w: 48,
		h: 86,
		seed: 7,
		antenna: false
	},
	{
		x: 906,
		w: 72,
		h: 170,
		seed: 8,
		antenna: false
	},
	{
		x: 986,
		w: 30,
		h: 236,
		seed: 9,
		antenna: true
	},
	{
		x: 1022,
		w: 58,
		h: 142,
		seed: 10,
		antenna: false
	},
	{
		x: 1088,
		w: 44,
		h: 198,
		seed: 11,
		antenna: false
	},
	{
		x: 1140,
		w: 46,
		h: 120,
		seed: 12,
		antenna: false
	}
];
function Windows({ x, y, w, h, seed }) {
	const nodes = [];
	let n = 0;
	for (let yy = y + 12; yy < y + h - 10; yy += 16) for (let xx = x + 8; xx < x + w - 8; xx += 14) {
		const kind = (n * 3 + seed) % 5;
		const wink = (n + seed) % 9 === 0;
		const cls = kind === 0 ? "win dim" : kind === 2 ? "win rose" : wink ? "win wink" : "win";
		nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			className: cls,
			x: xx,
			y: yy,
			width: "3.5",
			height: "5",
			rx: "0.6"
		}, `${seed}-${n}`));
		n += 1;
	}
	return nodes;
}
function Panorama({ motionOn }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "panorama",
		viewBox: "0 0 1200 560",
		role: "img",
		"aria-label": "Céu noturno entre duas cidades distantes, com duas estrelas ligadas por um fio de luz",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
					id: "horizon",
					x1: "0",
					y1: "0",
					x2: "0",
					y2: "1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "var(--color-night)",
							stopOpacity: "0"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "70%",
							stopColor: "var(--color-dusk)",
							stopOpacity: "0.2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "var(--color-night)",
							stopOpacity: "0.95"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
					id: "glow-l",
					cx: "50%",
					cy: "50%",
					r: "50%",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "var(--color-pearl)",
							stopOpacity: "0.95"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "40%",
							stopColor: "var(--color-lilac)",
							stopOpacity: "0.45"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "var(--color-lilac)",
							stopOpacity: "0"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
					id: "soft-glow",
					x: "-50%",
					y: "-50%",
					width: "200%",
					height: "200%",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feGaussianBlur", {
						stdDeviation: "2.2",
						result: "b"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("feMerge", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "b" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("feMergeNode", { in: "SourceGraphic" })] })]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "1200",
				height: "560",
				fill: "url(#horizon)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M390 168 Q600 96 830 214",
				fill: "none",
				stroke: "var(--color-lilac)",
				strokeWidth: "1.4",
				filter: "url(#soft-glow)",
				opacity: "0.9"
			}),
			motionOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				r: "3.2",
				fill: "var(--color-pearl)",
				filter: "url(#soft-glow)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("animateMotion", {
					dur: "11s",
					repeatCount: "indefinite",
					path: "M390 168 Q600 96 830 214"
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "390",
				cy: "168",
				r: "22",
				fill: "url(#glow-l)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "830",
				cy: "214",
				r: "22",
				fill: "url(#glow-l)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "390",
				cy: "168",
				r: "2.4",
				fill: "var(--color-pearl)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "830",
				cy: "214",
				r: "2.4",
				fill: "var(--color-pearl)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M1048 78c8 10 8 22 0 34 10-8 22-8 34 0-10-8-10-22 0-34-8 10-22 10-34 0z",
				fill: "var(--color-pearl)",
				opacity: "0.85"
			}),
			LEFT.map((b) => {
				const y = BASE - b.h;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: b.x,
						y,
						width: b.w,
						height: b.h,
						fill: "var(--color-night)"
					}),
					b.antenna ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: b.x + b.w / 2,
						y1: y,
						x2: b.x + b.w / 2,
						y2: y - 22,
						stroke: "var(--color-pearl)",
						strokeOpacity: "0.45"
					}) : null,
					Windows({
						x: b.x,
						y,
						w: b.w,
						h: b.h,
						seed: b.seed
					})
				] }, b.seed);
			}),
			RIGHT.map((b) => {
				const y = BASE - b.h;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: b.x,
						y,
						width: b.w,
						height: b.h,
						fill: "var(--color-night)"
					}),
					b.antenna ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: b.x + b.w / 2,
						y1: y,
						x2: b.x + b.w / 2,
						y2: y - 26,
						stroke: "var(--color-pearl)",
						strokeOpacity: "0.45"
					}) : null,
					Windows({
						x: b.x,
						y,
						w: b.w,
						h: b.h,
						seed: b.seed
					})
				] }, b.seed);
			})
		]
	});
}
var LINKS = [
	[0, 1],
	[1, 2],
	[2, 3],
	[3, 4],
	[1, 3]
];
function Constellation({ active, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "constellation",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			viewBox: "0 0 100 100",
			preserveAspectRatio: "none",
			"aria-hidden": "true",
			children: LINKS.map(([a, b]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: STAR_POS[a].x,
				y1: STAR_POS[a].y,
				x2: STAR_POS[b].x,
				y2: STAR_POS[b].y,
				className: "const-line",
				vectorEffect: "non-scaling-stroke"
			}, `${a}-${b}`))
		}), STAR_POS.map((pos, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: `star-btn ${active === index ? "is-on" : ""} delay-${index}`,
			style: {
				left: `${pos.x}%`,
				top: `${pos.y}%`
			},
			onClick: () => onPick(index),
			"aria-pressed": active === index,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "star-core" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "sr-only",
				children: ["Estrela ", index + 1]
			})]
		}, pos.x))]
	});
}
var BURST = Array.from({ length: 16 }, (_, i) => {
	const angle = i / 16 * Math.PI * 2;
	const dist = i % 2 === 0 ? 78 : 118;
	return {
		dx: Math.cos(angle) * dist,
		dy: Math.sin(angle) * dist * .72
	};
});
function TwoSkies({ litKey, left, right, motionOn }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `two-skies ${litKey > 0 ? "is-lit" : ""} ${motionOn ? "is-live" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mini-sky",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pulse-star" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mini-label",
					children: left
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bond",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mini-sky",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pulse-star delay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mini-label",
					children: right
				})]
			}),
			litKey > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "center-star",
				"aria-hidden": "true",
				children: BURST.map((bit, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
					["--dx"]: `${bit.dx}px`,
					["--dy"]: `${bit.dy}px`
				} }, i))
			}, litKey) : null
		]
	});
}
function NightMap({ mine, theirs, onMine, onTheirs }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "night-map",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 800 360",
				role: "img",
				"aria-label": "Mapa noturno simbólico com dois pontos ligados por estrelas",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M70 150 C 120 70, 230 60, 280 140 C 320 210, 250 280, 150 260 C 70 244, 30 200, 70 150 Z",
						className: "land"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M500 120 C 580 50, 720 70, 740 160 C 760 250, 650 300, 560 250 C 490 214, 450 180, 500 120 Z",
						className: "land"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M210 170 C 320 120, 430 210, 590 150",
						className: "map-road",
						fill: "none"
					}),
					[
						280,
						360,
						450,
						520
					].map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: x,
						cy: 150 + (i % 2 === 0 ? -18 : 22),
						r: "2.2",
						className: "map-dot"
					}, x))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "map-point left",
				onClick: onMine,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "star-core" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: mine })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "map-point right",
				onClick: onTheirs,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "star-core" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: theirs })]
			})
		]
	});
}
var HEART = heartPoints(40);
function HeartSky({ show }) {
	const [formed, setFormed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!show) {
			setFormed(false);
			return;
		}
		const id = requestAnimationFrame(() => setFormed(true));
		return () => cancelAnimationFrame(id);
	}, [show]);
	if (!show) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "heart-sky",
		"aria-hidden": "true",
		children: HEART.map((point, i) => {
			const sx = Math.cos(i * 2.17) * 130;
			const sy = Math.sin(i * 1.63) * 90;
			const x = formed ? point.x * 7.2 : sx;
			const y = formed ? point.y * 7.2 : sy;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: i % 6 === 0 ? "heart-star bright" : "heart-star",
				style: {
					transform: `translate(${x}px, ${y}px)`,
					transitionDelay: `${i * 16}ms`
				}
			}, i);
		})
	});
}
function EnvelopeGraphic({ open }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `env ${open ? "is-open" : ""}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "env-pocket" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "env-flap" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "env-seal",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 24 24",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 1.2 14.7 8.4 22.2 9l-5.4 4.8 1.6 7.2L12 17.4 5.6 21l1.6-7.2L1.8 9l7.5-.6L12 1.2Z" })
				})
			})
		]
	});
}
function GlassBox({ open }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `glass-box ${open ? "is-open" : ""}`,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "glass-lid" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "box-star" })]
	});
}
var NAV = [
	["ceu", "Céu"],
	["carta", "Carta"],
	["estrelas", "Estrelas"],
	["juntos", "Juntos"],
	["palavras", "Palavras"],
	["cinema", "Cinema"],
	["capsula", "Cápsula"],
	["mapa", "Mapa"]
];
var GROUPS = [
	{
		title: "Nomes",
		fields: [
			{
				key: "siteTitle",
				label: "Nome deste lugar"
			},
			{
				key: "myName",
				label: "Seu nome ou apelido"
			},
			{
				key: "theirName",
				label: "Nome ou apelido da pessoa"
			},
			{
				key: "signature",
				label: "Assinatura"
			}
		]
	},
	{
		title: "Abertura",
		fields: [{
			key: "introLine",
			label: "Frase da abertura",
			rows: 4
		}, {
			key: "introButton",
			label: "Botão da abertura"
		}]
	},
	{
		title: "Página principal",
		fields: [
			{
				key: "homeQuote",
				label: "Frase central",
				rows: 4
			},
			{
				key: "homeSub",
				label: "Mensagem menor",
				rows: 3
			},
			{
				key: "openLetterLabel",
				label: "Botão da carta"
			},
			{
				key: "exploreLabel",
				label: "Botão de explorar"
			}
		]
	},
	{
		title: "Carta principal",
		fields: [{
			key: "letterKicker",
			label: "Título da carta"
		}, {
			key: "letter",
			label: "Texto da carta",
			rows: 12
		}]
	},
	{
		title: "Céu compartilhado",
		fields: [
			{
				key: "sharedKicker",
				label: "Título"
			},
			{
				key: "sharedLine",
				label: "Frase",
				rows: 3
			},
			{
				key: "sharedButton",
				label: "Botão"
			},
			{
				key: "sharedAfter",
				label: "Mensagem depois de acender",
				rows: 4
			},
			{
				key: "sharedNote",
				label: "Nota simbólica"
			}
		]
	},
	{
		title: "Palavras guardadas",
		fields: [{
			key: "wordsTitle",
			label: "Título da seção"
		}]
	},
	{
		title: "Cinema",
		fields: [{
			key: "cinemaTitle",
			label: "Título da seção"
		}]
	},
	{
		title: "Cápsula",
		fields: [
			{
				key: "capsuleTitle",
				label: "Título"
			},
			{
				key: "capsuleIntro",
				label: "Introdução",
				rows: 3
			},
			{
				key: "capsuleFutureLabel",
				label: "Rótulo do futuro"
			},
			{
				key: "capsuleFuture",
				label: "Mensagem para o futuro",
				rows: 4
			},
			{
				key: "capsulePresentLabel",
				label: "Rótulo do presente"
			},
			{
				key: "capsulePresent",
				label: "Lembrança do presente",
				rows: 4
			},
			{
				key: "capsuleLearnLabel",
				label: "Rótulo do que quer conhecer"
			},
			{
				key: "capsuleLearn",
				label: "O que quer conhecer",
				rows: 4
			},
			{
				key: "capsuleWishLabel",
				label: "Rótulo do desejo"
			},
			{
				key: "capsuleWish",
				label: "Desejo para o próximo momento",
				rows: 4
			}
		]
	},
	{
		title: "Mapa",
		fields: [
			{
				key: "mapTitle",
				label: "Título"
			},
			{
				key: "mapCenter",
				label: "Frase do centro",
				rows: 3
			},
			{
				key: "myPlaceName",
				label: "Nome do seu lugar"
			},
			{
				key: "theirPlaceName",
				label: "Nome do lugar dela"
			},
			{
				key: "myWorldLabel",
				label: "Rótulo do seu mundo"
			},
			{
				key: "myWorld",
				label: "Texto do seu mundo",
				rows: 4
			},
			{
				key: "theirWorldLabel",
				label: "Rótulo do mundo dela"
			},
			{
				key: "theirWorld",
				label: "Texto do mundo dela",
				rows: 4
			}
		]
	},
	{
		title: "Surpresa final",
		fields: [
			{
				key: "finaleButton",
				label: "Botão que revela"
			},
			{
				key: "finale1",
				label: "Primeira mensagem",
				rows: 4
			},
			{
				key: "finale2",
				label: "Segunda mensagem",
				rows: 4
			},
			{
				key: "finaleBack",
				label: "Botão de voltar"
			}
		]
	},
	{
		title: "Música",
		fields: [{
			key: "musicTitle",
			label: "Nome que aparece no botão"
		}, {
			key: "musicUrl",
			label: "Link direto do áudio (opcional, https)"
		}]
	}
];
function Prose({ text }) {
	const parts = text.split(/\n{2,}/).filter((part) => part.trim().length > 0);
	if (!parts.length) return null;
	return parts.map((part, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: part }, index));
}
function Paper({ kicker, title, closeLabel, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "paper appear",
		children: [
			kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker on-paper",
				children: kicker
			}) : null,
			title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: title }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "paper-body",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn ghost dark",
				onClick: onClose,
				children: closeLabel
			})
		]
	});
}
function Signoff({ content }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "signoff",
		children: [content.theirName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Para ", content.theirName] }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "sign-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				viewBox: "0 0 24 24",
				className: "sig-star",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 0 13.8 8.4 22 12 13.8 15.6 12 24 10.2 15.6 2 12 10.2 8.4Z" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [content.signature, content.myName ? ` · ${content.myName}` : ""] })]
		})]
	});
}
function Photo({ which, at, alt }) {
	if (!at) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
		className: "photo-frame",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: `/api/media?key=${which}&v=${encodeURIComponent(at)}`,
			alt
		})
	});
}
function fileToBase64(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			const value = String(reader.result ?? "");
			const index = value.indexOf(",");
			resolve(index >= 0 ? value.slice(index + 1) : value);
		};
		reader.onerror = () => reject(/* @__PURE__ */ new Error("read"));
		reader.readAsDataURL(file);
	});
}
function guessMime(file, kind) {
	if ((kind === "audio" ? [
		"audio/mpeg",
		"audio/mp3",
		"audio/mp4",
		"audio/aac",
		"audio/ogg",
		"audio/wav",
		"audio/x-wav",
		"audio/webm"
	] : [
		"image/jpeg",
		"image/png",
		"image/webp"
	]).includes(file.type)) return file.type === "audio/mp3" ? "audio/mpeg" : file.type;
	const name = file.name.toLowerCase();
	if (kind === "audio") {
		if (name.endsWith(".mp3")) return "audio/mpeg";
		if (name.endsWith(".m4a")) return "audio/mp4";
		if (name.endsWith(".ogg")) return "audio/ogg";
		if (name.endsWith(".wav")) return "audio/wav";
		if (name.endsWith(".webm")) return "audio/webm";
	} else {
		if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
		if (name.endsWith(".png")) return "image/png";
		if (name.endsWith(".webp")) return "image/webp";
	}
	return null;
}
function mulberry32(seed) {
	let a = seed;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function Starfield() {
	const rand = mulberry32(20261015);
	const stars = Array.from({ length: 120 }, () => ({
		left: rand() * 100,
		top: rand() * 100,
		size: rand() * 2.1 + .8,
		delay: rand() * 5,
		dur: 2.4 + rand() * 3.6,
		opacity: .35 + rand() * .65
	}));
	const petals = Array.from({ length: 11 }, () => ({
		left: rand() * 100,
		delay: rand() * 14,
		dur: 16 + rand() * 14,
		size: 7 + rand() * 8,
		drift: -40 + rand() * 80
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "starfield",
		"aria-hidden": "true",
		children: [stars.map((star, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sky-star",
			style: {
				left: `${star.left}%`,
				top: `${star.top}%`,
				width: star.size,
				height: star.size,
				opacity: star.opacity,
				animationDelay: `${star.delay}s`,
				animationDuration: `${star.dur}s`
			}
		}, index)), petals.map((petal, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "petal",
			style: {
				left: `${petal.left}%`,
				width: petal.size,
				height: petal.size * .5,
				animationDelay: `${petal.delay}s`,
				animationDuration: `${petal.dur}s`,
				["--drift"]: `${petal.drift}px`
			}
		}, `p-${index}`))]
	});
}
function PointerDust() {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const root = ref.current;
		if (!root) return;
		function live() {
			return !document.querySelector(".page.motion-off");
		}
		function onMove(event) {
			if (!live() || event.pointerType === "touch" || !root) return;
			const dot = document.createElement("span");
			dot.className = "dust";
			dot.style.left = `${event.clientX}px`;
			dot.style.top = `${event.clientY}px`;
			root.appendChild(dot);
			window.setTimeout(() => dot.remove(), 650);
		}
		function onDown(event) {
			if (!live() || event.pointerType !== "touch" || !root) return;
			const ring = document.createElement("span");
			ring.className = "touch-ring";
			ring.style.left = `${event.clientX}px`;
			ring.style.top = `${event.clientY}px`;
			root.appendChild(ring);
			window.setTimeout(() => ring.remove(), 750);
		}
		window.addEventListener("pointermove", onMove);
		window.addEventListener("pointerdown", onDown);
		return () => {
			window.removeEventListener("pointermove", onMove);
			window.removeEventListener("pointerdown", onDown);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "dust-layer",
		"aria-hidden": "true"
	});
}
function Experience({ initial }) {
	const [snap, setSnap] = (0, import_react.useState)(initial);
	const [draft, setDraft] = (0, import_react.useState)(initial.content);
	const [dirty, setDirty] = (0, import_react.useState)(false);
	const [seenRev, setSeenRev] = (0, import_react.useState)(initial.revision);
	const [phase, setPhase] = (0, import_react.useState)("in");
	const [motionOn, setMotionOn] = (0, import_react.useState)(true);
	const [reading, setReading] = (0, import_react.useState)(false);
	const [letterOpen, setLetterOpen] = (0, import_react.useState)(false);
	const [star, setStar] = (0, import_react.useState)(null);
	const [envelope, setEnvelope] = (0, import_react.useState)(null);
	const [litKey, setLitKey] = (0, import_react.useState)(0);
	const [capsule, setCapsule] = (0, import_react.useState)(false);
	const [mapPoint, setMapPoint] = (0, import_react.useState)(null);
	const [finale, setFinale] = (0, import_react.useState)(false);
	const [finaleStep, setFinaleStep] = (0, import_react.useState)(0);
	const [active, setActive] = (0, import_react.useState)("ceu");
	const [musicState, setMusicState] = (0, import_react.useState)("idle");
	const [musicHint, setMusicHint] = (0, import_react.useState)("");
	const [syncNote, setSyncNote] = (0, import_react.useState)(false);
	const [adminOpen, setAdminOpen] = (0, import_react.useState)(false);
	const [unlocked, setUnlocked] = (0, import_react.useState)(false);
	const [password, setPassword] = (0, import_react.useState)("");
	const [checking, setChecking] = (0, import_react.useState)(false);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [uploading, setUploading] = (0, import_react.useState)(null);
	const [adminMsg, setAdminMsg] = (0, import_react.useState)("");
	const audioRef = (0, import_react.useRef)(null);
	const musicFileRef = (0, import_react.useRef)(null);
	const photo1Ref = (0, import_react.useRef)(null);
	const photo2Ref = (0, import_react.useRef)(null);
	const selfRev = (0, import_react.useRef)(null);
	const snapRef = (0, import_react.useRef)(snap);
	snapRef.current = snap;
	const content = snap.content;
	(0, import_react.useEffect)(() => {
		const motion = localStorage.getItem("ceu-motion");
		const read = localStorage.getItem("ceu-reading");
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		if (motion === "off" || reduce && motion !== "on") setMotionOn(false);
		if (read === "on") setReading(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (dirty) return;
		setDraft((prev) => JSON.stringify(prev) === JSON.stringify(snap.content) ? prev : snap.content);
		setSeenRev(snap.revision);
	}, [snap, dirty]);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		let timer = 0;
		async function pull() {
			if (cancel || document.hidden) return;
			try {
				const next = await getSky();
				if (cancel) return;
				const prev = snapRef.current;
				if (signature(prev) === signature(next)) return;
				const external = next.revision !== prev.revision && next.revision !== selfRev.current;
				setSnap(next);
				if (external) {
					setSyncNote(true);
					window.setTimeout(() => setSyncNote(false), 2800);
				}
			} catch {}
		}
		function loop() {
			timer = window.setTimeout(async () => {
				await pull();
				if (!cancel) loop();
			}, 3e3);
		}
		loop();
		const onVis = () => {
			if (!document.hidden) pull();
		};
		document.addEventListener("visibilitychange", onVis);
		window.addEventListener("focus", onVis);
		return () => {
			cancel = true;
			window.clearTimeout(timer);
			document.removeEventListener("visibilitychange", onVis);
			window.removeEventListener("focus", onVis);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!finale) {
			setFinaleStep(0);
			return;
		}
		const first = window.setTimeout(() => setFinaleStep(1), motionOn ? 900 : 0);
		const second = window.setTimeout(() => setFinaleStep(2), motionOn ? 2600 : 0);
		return () => {
			window.clearTimeout(first);
			window.clearTimeout(second);
		};
	}, [finale, motionOn]);
	(0, import_react.useEffect)(() => {
		const key = `${snap.musicAt ?? ""}|${snap.content.musicUrl}`;
		const audio = audioRef.current;
		if (!audio) return;
		if (audio.dataset.key && audio.dataset.key !== key && musicState === "on") {
			audio.pause();
			setMusicState("idle");
			setMusicHint("A música foi atualizada. Toque de novo se quiser ouvir.");
		}
		audio.dataset.key = key;
	}, [
		snap.musicAt,
		snap.content.musicUrl,
		musicState
	]);
	(0, import_react.useEffect)(() => {
		const nodes = NAV.map(([id]) => document.getElementById(id)).filter((node) => Boolean(node));
		const observer = new IntersectionObserver((entries) => {
			const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (visible?.target.id) setActive(visible.target.id);
		}, {
			rootMargin: "-35% 0px -45% 0px",
			threshold: [.15, .4]
		});
		nodes.forEach((node) => observer.observe(node));
		return () => observer.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!adminOpen) return;
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = previous;
		};
	}, [adminOpen]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.key !== "Escape") return;
			if (adminOpen) {
				setAdminOpen(false);
				return;
			}
			setLetterOpen(false);
			setStar(null);
			setEnvelope(null);
			setCapsule(false);
			setMapPoint(null);
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [adminOpen]);
	function go(id) {
		document.getElementById(id)?.scrollIntoView({
			behavior: motionOn ? "smooth" : "auto",
			block: "start"
		});
	}
	function closeIntro() {
		if (phase !== "in") return;
		if (!motionOn) {
			setPhase("done");
			return;
		}
		setPhase("out");
		window.setTimeout(() => setPhase("done"), 700);
	}
	function musicSource() {
		if (snap.musicAt) return `/api/media?key=music&v=${encodeURIComponent(snap.musicAt)}`;
		return content.musicUrl;
	}
	async function toggleMusic() {
		const audio = audioRef.current;
		if (!audio) return;
		if (musicState !== "idle") {
			audio.pause();
			audio.currentTime = 0;
			setMusicState("idle");
			return;
		}
		const src = musicSource();
		if (!src) {
			setMusicHint("A música ainda não foi colocada neste céu. O botão fica pronto para quando ela chegar.");
			return;
		}
		setMusicHint("");
		setMusicState("loading");
		const absolute = new URL(src, window.location.href).href;
		if (audio.src !== absolute) audio.src = src;
		try {
			await audio.play();
			setMusicState("on");
		} catch {
			setMusicState("idle");
			setMusicHint("Não consegui tocar agora. Tenta de novo em um instante.");
		}
	}
	function setText(key, value) {
		setDirty(true);
		setDraft((prev) => ({
			...prev,
			[key]: value
		}));
	}
	async function unlock(event) {
		event.preventDefault();
		setChecking(true);
		setAdminMsg("");
		try {
			const result = await checkAdmin({ data: { password } });
			if (!result.ok) {
				setAdminMsg(result.error);
				return;
			}
			setUnlocked(true);
		} catch {
			setAdminMsg("Não consegui confirmar agora.");
		} finally {
			setChecking(false);
		}
	}
	async function onSave(event) {
		event.preventDefault();
		setSaving(true);
		setAdminMsg("");
		try {
			const result = await saveSky({ data: {
				password,
				content: draft
			} });
			if (!result.ok) {
				setAdminMsg(result.error);
				return;
			}
			selfRev.current = result.revision;
			setSnap(result);
			setDraft(result.content);
			setDirty(false);
			setSeenRev(result.revision);
			setAdminMsg("Guardado. Quem abrir o site, de qualquer lugar, passa a ver esta versão.");
		} catch {
			setAdminMsg("Não consegui sincronizar agora. Tenta de novo.");
		} finally {
			setSaving(false);
		}
	}
	async function onFile(kind, file) {
		if (!file) return;
		const mime = guessMime(file, kind === "music" ? "audio" : "image");
		if (!mime) {
			setAdminMsg("Usa MP3, M4A, OGG, WAV ou uma foto JPG, PNG ou WebP.");
			return;
		}
		const max = kind === "music" ? 2e6 : 7e5;
		if (file.size > max) {
			setAdminMsg(kind === "music" ? "O áudio precisa ter até 2 MB." : "A foto precisa ter até 700 KB.");
			return;
		}
		setUploading(kind);
		setAdminMsg("");
		try {
			const data = await fileToBase64(file);
			const result = await saveMedia({ data: {
				password,
				key: kind,
				mime,
				data
			} });
			if (!result.ok) {
				setAdminMsg(result.error);
				return;
			}
			selfRev.current = result.revision;
			setSnap(result);
			setSeenRev(result.revision);
			setAdminMsg(kind === "music" ? "Música guardada para todo mundo." : "Fotografia guardada para todo mundo.");
		} catch {
			setAdminMsg("Não consegui enviar o arquivo agora.");
		} finally {
			setUploading(null);
		}
	}
	async function clearMedia(kind) {
		setUploading(kind);
		setAdminMsg("");
		try {
			const result = await saveMedia({ data: {
				password,
				key: kind,
				mime: "",
				data: ""
			} });
			if (!result.ok) {
				setAdminMsg(result.error);
				return;
			}
			selfRev.current = result.revision;
			setSnap(result);
			setSeenRev(result.revision);
			if (kind === "music") {
				audioRef.current?.pause();
				setMusicState("idle");
			}
			setAdminMsg("Removido para todo mundo.");
		} catch {
			setAdminMsg("Não consegui remover agora.");
		} finally {
			setUploading(null);
		}
	}
	const openStar = star !== null ? content.stars[star] : null;
	const openEnvelope = envelope !== null ? content.envelopes[envelope] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `page ${motionOn ? "" : "motion-off"} ${reading ? "reading" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nebula",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Starfield, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PointerDust, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				preload: "none",
				onEnded: () => setMusicState("idle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "secret-star",
				"aria-label": "Canto reservado",
				onClick: () => setAdminOpen(true),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 24 24",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 1.4 14.2 8.8 21.8 9.4 16 14.2 17.8 21.6 12 17.6 6.2 21.6 8 14.2 2.2 9.4 9.8 8.8Z" })
				})
			}),
			phase !== "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `intro ${phase === "out" ? "intro-out" : ""}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "skip",
					onClick: closeIntro,
					children: "Pular introdução"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "intro-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: content.siteTitle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							className: "intro-const",
							viewBox: "0 0 220 90",
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "48",
									y1: "58",
									x2: "172",
									y2: "34",
									className: "draw-line"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "48",
									cy: "58",
									r: "3.2",
									className: "intro-star a"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
									cx: "172",
									cy: "34",
									r: "3.2",
									className: "intro-star b"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "intro-copy",
							children: content.introLine
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn solid intro-copy late",
							onClick: closeIntro,
							children: content.introButton
						})
					]
				})]
			}) : null,
			phase !== "in" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "top-tools",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": reading,
					"aria-label": reading ? "Desativar modo de leitura" : "Ativar modo de leitura",
					onClick: () => setReading((value) => {
						localStorage.setItem("ceu-reading", value ? "off" : "on");
						return !value;
					}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": motionOn,
					"aria-label": motionOn ? "Desativar animações" : "Ativar animações",
					onClick: () => setMotionOn((value) => {
						localStorage.setItem("ceu-motion", value ? "off" : "on");
						return !value;
					}),
					children: motionOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {})
				})]
			}) : null,
			syncNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sync-pill",
				role: "status",
				children: "O céu foi atualizado"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: phase === "in" ? "held" : "shown",
				inert: phase === "in" ? true : void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "ceu",
						className: "block hero",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: content.siteTitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panorama, { motionOn }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass quote",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: content.homeQuote }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: content.homeSub })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "action-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn solid",
									onClick: () => {
										setLetterOpen(true);
										go("carta");
									},
									children: content.openLetterLabel
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn ghost",
									onClick: () => go("estrelas"),
									children: content.exploreLabel
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "carta",
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: content.letterKicker
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Palavras que atravessam quilômetros" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "env-hit",
								"aria-expanded": letterOpen,
								onClick: () => setLetterOpen(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnvelopeGraphic, { open: letterOpen }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Abrir a carta"
								})]
							}),
							letterOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Paper, {
								kicker: "Carta",
								closeLabel: "Fechar a carta",
								onClose: () => setLetterOpen(false),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: content.letter }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signoff, { content }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
										which: "photo1",
										at: snap.photo1At,
										alt: "Fotografia deixada junto da carta"
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hint",
								children: "O envelope espera por um toque."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "estrelas",
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "Constelação"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: content.starsTitle }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "lede",
								children: "Cinco estrelas. Nenhuma se abre sozinha."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Constellation, {
								active: star,
								onPick: (index) => setStar((current) => current === index ? null : index)
							}),
							openStar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paper, {
								kicker: `Estrela ${star + 1}`,
								title: openStar.title,
								closeLabel: "Fechar estrela",
								onClose: () => setStar(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: openStar.body })
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "juntos",
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: content.sharedKicker
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "O mesmo gesto, em dois céus" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TwoSkies, {
								litKey,
								left: content.myPlaceName,
								right: content.theirPlaceName,
								motionOn
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "lede quote-line",
								children: content.sharedLine
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn solid",
								onClick: () => setLitKey((value) => value + 1),
								children: content.sharedButton
							}),
							litKey > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "glass after appear",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: content.sharedAfter })
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hint",
								children: content.sharedNote
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "palavras",
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "Envelopes"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: content.wordsTitle }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "envelope-grid",
								children: content.envelopes.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: `mini-env ${envelope === index ? "is-on" : ""}`,
									"aria-expanded": envelope === index,
									onClick: () => setEnvelope(index),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnvelopeGraphic, { open: envelope === index }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.label })]
								}, item.label))
							}),
							openEnvelope ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paper, {
								title: openEnvelope.label,
								closeLabel: "Fechar e voltar aos envelopes",
								onClose: () => setEnvelope(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: openEnvelope.body })
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "cinema",
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "À distância"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: content.cinemaTitle }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "screen",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "a tela acende quando a gente combina" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
								which: "photo2",
								at: snap.photo2At,
								alt: "Fotografia deixada na sala de cinema"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "card-grid",
								children: content.cinema.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "glass cinema-card",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: card.title }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: card.body }),
										card.link ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: card.link,
											target: "_blank",
											rel: "noreferrer",
											children: card.linkLabel || "Abrir"
										}) : null
									]
								}, card.title))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "capsula",
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "Continuidade"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: content.capsuleTitle }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "lede",
								children: content.capsuleIntro
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "box-hit",
								"aria-expanded": capsule,
								onClick: () => setCapsule(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlassBox, { open: capsule }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Abrir a cápsula"
								})]
							}),
							capsule ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Paper, {
								closeLabel: "Fechar a cápsula",
								onClose: () => setCapsule(false),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: content.capsuleFutureLabel }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: content.capsuleFuture }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: content.capsulePresentLabel }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: content.capsulePresent }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: content.capsuleLearnLabel }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: content.capsuleLearn }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: content.capsuleWishLabel }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: content.capsuleWish })
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hint",
								children: "A caixa fica fechada até você querer abri-la."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						id: "mapa",
						className: "block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "Dois mundos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: content.mapTitle }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NightMap, {
								mine: content.myPlaceName,
								theirs: content.theirPlaceName,
								onMine: () => setMapPoint("mine"),
								onTheirs: () => setMapPoint("theirs")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "lede quote-line",
								children: content.mapCenter
							}),
							mapPoint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paper, {
								title: mapPoint === "mine" ? content.myWorldLabel : content.theirWorldLabel,
								closeLabel: "Fechar",
								onClose: () => setMapPoint(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prose, { text: mapPoint === "mine" ? content.myWorld : content.theirWorld })
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hint",
								children: "Toque nos dois pontos luminosos."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						id: "final",
						className: `block finale ${finale ? "is-open" : ""}`,
						children: !finale ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn ghost finale-btn",
							onClick: () => setFinale(true),
							children: content.finaleButton
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeartSky, { show: finale }),
							finaleStep >= 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "finale-copy appear",
								children: content.finale1
							}) : null,
							finaleStep >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "finale-copy appear",
									children: content.finale2
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signoff, { content }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn ghost",
									onClick: () => {
										setFinale(false);
										go("ceu");
									},
									children: content.finaleBack
								})
							] }) : null
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "colophon",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Um lugar só nosso. Nada aqui pede cadastro." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-link",
							onClick: () => go("ceu"),
							children: "Voltar ao início"
						})]
					})
				]
			}),
			phase !== "in" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dock",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: `music-btn ${musicState === "on" ? "is-on" : ""}`,
						onClick: () => void toggleMusic(),
						"aria-pressed": musicState === "on",
						children: [
							musicState === "on" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: musicState === "on" ? "Cancelar" : `Ouvir ${content.musicTitle}` }),
							musicState === "on" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: content.musicTitle }) : null
						]
					}),
					musicHint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "music-hint",
						role: "status",
						children: musicHint
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						"aria-label": "Seções",
						children: NAV.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-current": active === id ? "true" : void 0,
							onClick: () => go(id),
							children: label
						}, id))
					})
				]
			}) : null,
			adminOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "admin-layer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "admin-backdrop",
					"aria-label": "Fechar o canto reservado",
					onClick: () => setAdminOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "admin-sheet",
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "admin-title",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "admin-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "Canto reservado"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "admin-title",
							children: "O céu, por dentro"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "icon-x",
							"aria-label": "Fechar",
							onClick: () => setAdminOpen(false),
							children: "×"
						})]
					}), !unlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: (event) => void unlock(event),
						className: "admin-lock",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Se este céu é seu de escrever, entra. Se é seu de ler, pode voltar — nada se perde." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field",
								htmlFor: "admin-pass",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Senha" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "admin-pass",
									type: "password",
									autoComplete: "current-password",
									value: password,
									onChange: (event) => setPassword(event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "btn solid",
								disabled: checking,
								children: checking ? "Conferindo…" : "Entrar"
							}),
							adminMsg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "admin-msg",
								children: adminMsg
							}) : null
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: (event) => void onSave(event),
						className: "admin-form",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hint light",
								children: "O que você guardar aqui aparece para qualquer pessoa que abrir o site, onde ela estiver. A música não começa sozinha."
							}),
							dirty && snap.revision !== seenRev ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "admin-msg",
								children: "Chegou uma versão mais nova de outro lugar. Salvar agora substitui essa versão."
							}) : null,
							GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								open: group.title === "Nomes",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", { children: group.title }), group.fields.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									htmlFor: `f-${field.key}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: field.label }), field.rows ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: `f-${field.key}`,
										rows: field.rows,
										value: draft[field.key],
										onChange: (event) => setText(field.key, event.target.value)
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: `f-${field.key}`,
										value: draft[field.key],
										onChange: (event) => setText(field.key, event.target.value)
									})]
								}, field.key))]
							}, group.title)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", { children: "Constelação" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									htmlFor: "f-starsTitle",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Título da seção" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "f-starsTitle",
										value: draft.starsTitle,
										onChange: (event) => setText("starsTitle", event.target.value)
									})]
								}),
								draft.stars.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "subblock",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										htmlFor: `star-t-${index}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"Estrela ",
											index + 1,
											" — título"
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: `star-t-${index}`,
											value: item.title,
											onChange: (event) => {
												const value = event.target.value;
												setDirty(true);
												setDraft((prev) => {
													const stars = prev.stars.map((starNote, starIndex) => starIndex === index ? {
														...starNote,
														title: value
													} : starNote);
													return {
														...prev,
														stars
													};
												});
											}
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										htmlFor: `star-b-${index}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"Estrela ",
											index + 1,
											" — texto"
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											id: `star-b-${index}`,
											rows: 5,
											value: item.body,
											onChange: (event) => {
												const value = event.target.value;
												setDirty(true);
												setDraft((prev) => {
													const stars = prev.stars.map((starNote, starIndex) => starIndex === index ? {
														...starNote,
														body: value
													} : starNote);
													return {
														...prev,
														stars
													};
												});
											}
										})]
									})]
								}, index))
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", { children: "Quatro envelopes" }), draft.envelopes.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "subblock",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									htmlFor: `env-l-${index}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Envelope ",
										index + 1,
										" — por fora"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: `env-l-${index}`,
										rows: 2,
										value: item.label,
										onChange: (event) => {
											const value = event.target.value;
											setDirty(true);
											setDraft((prev) => {
												const envelopes = prev.envelopes.map((note, noteIndex) => noteIndex === index ? {
													...note,
													label: value
												} : note);
												return {
													...prev,
													envelopes
												};
											});
										}
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "field",
									htmlFor: `env-b-${index}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Envelope ",
										index + 1,
										" — por dentro"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: `env-b-${index}`,
										rows: 5,
										value: item.body,
										onChange: (event) => {
											const value = event.target.value;
											setDirty(true);
											setDraft((prev) => {
												const envelopes = prev.envelopes.map((note, noteIndex) => noteIndex === index ? {
													...note,
													body: value
												} : note);
												return {
													...prev,
													envelopes
												};
											});
										}
									})]
								})]
							}, index))] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", { children: "Cartões do cinema e links" }), draft.cinema.map((card, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "subblock",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										htmlFor: `cin-t-${index}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"Cartão ",
											index + 1,
											" — título"
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: `cin-t-${index}`,
											value: card.title,
											onChange: (event) => {
												const value = event.target.value;
												setDirty(true);
												setDraft((prev) => {
													const cinema = prev.cinema.map((item, itemIndex) => itemIndex === index ? {
														...item,
														title: value
													} : item);
													return {
														...prev,
														cinema
													};
												});
											}
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										htmlFor: `cin-b-${index}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											"Cartão ",
											index + 1,
											" — texto"
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											id: `cin-b-${index}`,
											rows: 4,
											value: card.body,
											onChange: (event) => {
												const value = event.target.value;
												setDirty(true);
												setDraft((prev) => {
													const cinema = prev.cinema.map((item, itemIndex) => itemIndex === index ? {
														...item,
														body: value
													} : item);
													return {
														...prev,
														cinema
													};
												});
											}
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										htmlFor: `cin-u-${index}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Link opcional" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: `cin-u-${index}`,
											value: card.link,
											placeholder: "https://",
											onChange: (event) => {
												const value = event.target.value;
												setDirty(true);
												setDraft((prev) => {
													const cinema = prev.cinema.map((item, itemIndex) => itemIndex === index ? {
														...item,
														link: value
													} : item);
													return {
														...prev,
														cinema
													};
												});
											}
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										htmlFor: `cin-ll-${index}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Texto do link" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: `cin-ll-${index}`,
											value: card.linkLabel,
											onChange: (event) => {
												const value = event.target.value;
												setDirty(true);
												setDraft((prev) => {
													const cinema = prev.cinema.map((item, itemIndex) => itemIndex === index ? {
														...item,
														linkLabel: value
													} : item);
													return {
														...prev,
														cinema
													};
												});
											}
										})]
									})
								]
							}, index))] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								open: true,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", { children: "Arquivo de música e fotografias" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "hint light",
										children: [
											"O botão público se chama ",
											content.musicTitle,
											". Envie um áudio que você tenha direito de usar — de preferência MP3, até 2 MB — ou cole um link direto no campo de música e guarde os textos. Fotos são opcionais, até 700 KB."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "upload-row",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "btn ghost",
												onClick: () => musicFileRef.current?.click(),
												disabled: uploading !== null,
												children: uploading === "music" ? "Enviando…" : snap.musicAt ? "Trocar a música" : "Enviar música"
											}),
											snap.musicAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "btn ghost",
												onClick: () => void clearMedia("music"),
												disabled: uploading !== null,
												children: "Tirar música"
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												ref: musicFileRef,
												className: "sr-only",
												type: "file",
												accept: "audio/mpeg,audio/mp4,audio/ogg,audio/wav,audio/webm,.mp3,.m4a,.ogg,.wav",
												onChange: (event) => {
													onFile("music", event.target.files?.[0]);
													event.target.value = "";
												}
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "upload-row",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "btn ghost",
												onClick: () => photo1Ref.current?.click(),
												disabled: uploading !== null,
												children: uploading === "photo1" ? "Enviando…" : "Foto da carta"
											}),
											snap.photo1At ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "btn ghost",
												onClick: () => void clearMedia("photo1"),
												disabled: uploading !== null,
												children: "Tirar foto"
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												ref: photo1Ref,
												className: "sr-only",
												type: "file",
												accept: "image/jpeg,image/png,image/webp",
												onChange: (event) => {
													onFile("photo1", event.target.files?.[0]);
													event.target.value = "";
												}
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "upload-row",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "btn ghost",
												onClick: () => photo2Ref.current?.click(),
												disabled: uploading !== null,
												children: uploading === "photo2" ? "Enviando…" : "Foto do cinema"
											}),
											snap.photo2At ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "btn ghost",
												onClick: () => void clearMedia("photo2"),
												disabled: uploading !== null,
												children: "Tirar foto"
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												ref: photo2Ref,
												className: "sr-only",
												type: "file",
												accept: "image/jpeg,image/png,image/webp",
												onChange: (event) => {
													onFile("photo2", event.target.files?.[0]);
													event.target.value = "";
												}
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
										which: "photo1",
										at: snap.photo1At,
										alt: "Prévia da fotografia da carta"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, {
										which: "photo2",
										at: snap.photo2At,
										alt: "Prévia da fotografia do cinema"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "save-bar",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "btn solid",
										disabled: saving,
										children: saving ? "Guardando…" : "Guardar neste céu"
									}),
									adminMsg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "admin-msg",
										role: "status",
										children: adminMsg
									}) : null,
									snap.updatedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "hint light",
										children: [
											"Última sincronização:",
											" ",
											new Date(snap.updatedAt).toLocaleString("pt-BR", {
												dateStyle: "short",
												timeStyle: "short"
											})
										]
									}) : null
								]
							})
						]
					})]
				})]
			}) : null
		]
	});
}
function Home() {
	const data = Route$1.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Experience, { initial: data });
}
//#endregion
export { Home as component };
