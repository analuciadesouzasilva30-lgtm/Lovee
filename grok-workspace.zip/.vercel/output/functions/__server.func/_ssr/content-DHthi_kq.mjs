import { r as __exportAll$1 } from "../_runtime.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/content-DHthi_kq.js
var content_DHthi_kq_exports = /* @__PURE__ */ __exportAll$1({
	a: () => sanitize,
	i: () => heartPoints,
	n: () => content_exports,
	o: () => signature,
	r: () => freshState,
	s: () => __exportAll,
	t: () => STAR_POS
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var content_exports = /* @__PURE__ */ __exportAll({
	DEFAULTS: () => DEFAULTS,
	STAR_POS: () => STAR_POS,
	freshState: () => freshState,
	heartPoints: () => heartPoints,
	sanitize: () => sanitize,
	signature: () => signature
});
var DEFAULTS = {
	siteTitle: "Entre Dois Céus",
	myName: "",
	theirName: "você",
	signature: "com cuidado, daqui",
	musicTitle: "You Belong With Me",
	musicUrl: "",
	introLine: "Existem distâncias que separam lugares, mas não conseguem explicar tudo o que conecta duas pessoas.",
	introButton: "Descobrir o que preparei para você",
	homeQuote: "Se eu pudesse diminuir qualquer distância agora, escolheria aquela que existe entre nós.",
	homeSub: "Enquanto isso não acontece, fiz um lugar onde você sempre pode encontrar um pedacinho de mim.",
	openLetterLabel: "Abrir minha carta",
	exploreLabel: "Explorar nosso pequeno universo",
	letterKicker: "Uma carta que atravessa quilômetros",
	letter: "Eu queria poder estar mais perto de você, mas, enquanto isso não é possível, resolvi criar algo que pudesse atravessar essa distância.\n\nTalvez seja apenas um site para quem olha de fora. Mas, para mim, cada detalhe representa uma vontade: a de compartilhar mais momentos com você, de conhecer cada vez mais o seu mundo e de fazer parte dos seus dias, mesmo quando não posso estar aí.\n\nNão posso prometer que a distância sempre será fácil. Posso, porém, escolher ser sincero sobre o que sinto e aproveitar as oportunidades que temos para construir algo verdadeiro.\n\nEntão, quando sentir vontade de encontrar um pedacinho de mim, volte aqui. Este pequeno universo foi criado pensando em você.",
	starsTitle: "Pequenas coisas que aproximam dois mundos",
	stars: [
		{
			title: "O que me faz lembrar de você",
			body: "Não é uma cena que eu vá inventar aqui. É o intervalo depois que a conversa acaba, quando alguma coisa sua continua no dia: um jeito de falar, uma pausa, a sensação de que você esteve perto mesmo sem estar. Quando eu souber nomear melhor esses detalhes, eles vão estar nesta estrela — do seu jeito, não de um jeito genérico."
		},
		{
			title: "O que eu gostaria de te contar agora",
			body: "Se a gente estivesse falando neste minuto, eu não começaria com um discurso. Diria que estou aqui, sem pressa de definir o que isso precisa ser, e com vontade de saber como foi o seu dia de verdade. A distância existe. O interesse também. Um não apaga o outro."
		},
		{
			title: "Um momento que quero viver com você",
			body: "Quero uma noite sem relógio. A gente escolhe o mesmo filme, cada um na própria casa, e comenta no meio, como se a sala fosse uma só. Quero também as conversas sem pauta, em que o mundo de um vai cabendo no do outro. Nada de palco. Só presença, mesmo de longe."
		},
		{
			title: "Quando a saudade aparecer",
			body: "Se hoje o quilômetro parecer maior, não precisa resolver a distância inteira. Respira. Eu também sinto, e não vou fingir que isso é leve o tempo todo. Este lugar continua aqui para quando você quiser um sinal de que não está pensando nisso sozinha."
		},
		{
			title: "Uma coisa que quero que você saiba",
			body: "Isto não é um jogo de frases bonitas. É uma escolha pequena e repetida: lembrar de você com respeito, sem prometer o que ainda não posso cumprir, e sem transformar carinho em cobrança. A distância pesa. Mesmo assim, eu escolho continuar te conhecendo no ritmo que for possível."
		}
	],
	sharedKicker: "O céu compartilhado",
	sharedLine: "Dois lugares. Duas rotinas. Dois céus. E uma conexão que merece ser descoberta com calma.",
	sharedButton: "Acender nossa estrela",
	sharedAfter: "Esta estrela não marca um endereço. Ela só diz que, neste instante, eu também estou olhando para o mesmo símbolo que você. Onde quer que a gente esteja.",
	sharedNote: "É uma representação artística. Não é a posição real de ninguém.",
	wordsTitle: "Guardei algumas palavras para você",
	envelopes: [
		{
			label: "Abra quando sentir saudade.",
			body: "A saudade não precisa ser escondida para ficar suportável. Ela só avisa que você importa daqui também. Se o dia estiver longo, fica com isto: eu penso em você sem drama e sem pressa — do jeito de quem quer que você esteja bem, mesmo quando não posso estar ao lado."
		},
		{
			label: "Abra quando quiser sorrir.",
			body: "Guardei esta para um instante leve. Imagina a gente perdendo a pose no meio de um assunto sério, porque alguma besteira atravessou a conversa e nenhum dos dois conseguiu segurar. Não vou inventar que isso já aconteceu. Só digo que é o tipo de momento que eu gostaria de ter com você."
		},
		{
			label: "Abra quando quiser saber o que penso sobre você.",
			body: "Eu penso em você como alguém com rotina, gostos, silêncios e um mundo que não me pertence — e que, mesmo assim, me interessa. Não quero te reduzir a uma ideia romântica. Quero te conhecer de verdade, sem te empurrar a ser nada além de quem você é."
		},
		{
			label: "Abra quando quiser imaginar nosso próximo momento.",
			body: "O próximo momento não precisa ser grandioso para ser nosso. Pode ser uma ligação curta, um filme combinado, uma mensagem no fim do dia. Eu imagino a gente presente, sem transformar o encontro em prova de alguma coisa. Só dois mundos se encostando por um tempo."
		}
	],
	cinemaTitle: "Nosso cinema à distância",
	cinema: [
		{
			title: "Uma noite de filme",
			body: "Escolhe um filme sem compromisso de ser o filme da vida. A gente combina a hora, dá o play junto e deixa os comentários atravessarem — cada um na própria casa, na mesma história. Se quiser, deixa o link do que você gostaria de ver.",
			link: "",
			linkLabel: "Ver a sugestão"
		},
		{
			title: "Uma conversa sem pressa",
			body: "Nem todo encontro precisa de programa. Às vezes basta reservar um tempo em que ninguém está tentando render. Contar o dia, ficar em silêncio, rir de uma coisa pequena. Eu topo esse tipo de noite com você.",
			link: "",
			linkLabel: "Combinar por aqui"
		},
		{
			title: "Uma música para nós",
			body: "A música deste céu é You Belong With Me. Não porque a nossa história já esteja escrita numa letra, mas porque tem nela a vontade de estar perto de alguém que já ocupa os pensamentos. Quando quiser, o botão luminoso toca — e para, se você preferir silêncio.",
			link: "",
			linkLabel: "Abrir a música"
		}
	],
	capsuleTitle: "Para o nós de amanhã",
	capsuleIntro: "Uma caixa pequena, sem contagem regressiva e sem cobrança. Só continuidade: o que eu consigo dizer hoje para quem a gente talvez seja depois.",
	capsuleFutureLabel: "Uma mensagem para o futuro",
	capsulePresentLabel: "Uma lembrança do presente",
	capsuleLearnLabel: "Algo que eu gostaria de conhecer sobre você",
	capsuleWishLabel: "Um desejo realista para o próximo momento",
	capsuleFuture: "Se um dia vocês lerem isto com mais caminho andado, espero que a honestidade de agora ainda esteja ali. Sem corrida. Sem carinho disfarçado de prazo. Só a vontade de construir algo que caiba na vida real dos dois.",
	capsulePresent: "Do presente, guardo isto: existe uma pessoa que, mesmo longe, me fez querer criar um lugar em vez de apenas esperar. Não vou inventar uma memória que ainda não vivemos. O começo já é este cuidado.",
	capsuleLearn: "Quero conhecer o que te anima num dia comum, o que te cansa, o que você defende sem alarde e o que você só conta para quem merece. Sem questionário. Na conversa, quando você quiser.",
	capsuleWish: "No próximo momento compartilhado, quero uma coisa possível: um tempo de qualidade, mesmo que curto, em que a gente esteja de verdade um para o outro. Sem plateia e sem promessa maior do que o instante.",
	mapTitle: "O mapa das pequenas distâncias",
	mapCenter: "Não precisamos viver no mesmo lugar para aprender a fazer parte do mundo um do outro.",
	myPlaceName: "Daqui",
	theirPlaceName: "Aí",
	myWorldLabel: "Meu mundo",
	theirWorldLabel: "Seu mundo",
	myWorld: "Daqui, a rotina segue. Os dias passam e, no meio de coisas comuns, o pensamento volta para você. Não é um mundo parado esperando. É um mundo que aprendeu a abrir um espaço seu sem pedir que você abandone o seu.",
	theirWorld: "O seu mundo é seu. Tem horários, pessoas, ruas e hábitos que eu ainda não conheço por completo — e tudo bem. Eu não quero invadir. Quero aprender a fazer parte, do tamanho que você permitir, sem apagar o que já é seu.",
	finaleButton: "Ainda tem uma última coisa",
	finale1: "Eu não criei este lugar porque a distância é pequena. Criei porque, mesmo existindo tantos quilômetros entre nós, você despertou em mim a vontade de fazer algo que chegasse até você.",
	finale2: "E, se algum dia você voltar aqui, espero que encontre mais do que palavras bonitas. Espero que encontre um pouco daquilo que estou tentando construir com você, um dia de cada vez.",
	finaleBack: "Voltar ao nosso céu"
};
var TEXT_LIMIT = 6e3;
function safeUrl(value) {
	if (typeof value !== "string") return "";
	const trimmed = value.trim().slice(0, 600);
	if (!trimmed) return "";
	try {
		const url = new URL(trimmed);
		if (url.protocol !== "http:" && url.protocol !== "https:") return "";
		return url.toString();
	} catch {
		return "";
	}
}
function asRecord(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return null;
	return value;
}
function sanitize(input) {
	const src = asRecord(input) ?? {};
	const next = structuredClone(DEFAULTS);
	Object.keys(DEFAULTS).forEach((key) => {
		if (key === "stars" || key === "envelopes" || key === "cinema") return;
		const raw = src[key];
		if (key === "musicUrl") {
			next.musicUrl = safeUrl(raw);
			return;
		}
		if (typeof raw === "string") next[key] = raw.slice(0, TEXT_LIMIT);
	});
	next.stars = DEFAULTS.stars.map((fallback, index) => {
		const item = Array.isArray(src.stars) ? asRecord(src.stars[index]) : null;
		if (!item) return { ...fallback };
		return {
			title: typeof item.title === "string" ? item.title.slice(0, 600) : fallback.title,
			body: typeof item.body === "string" ? item.body.slice(0, TEXT_LIMIT) : fallback.body
		};
	});
	next.envelopes = DEFAULTS.envelopes.map((fallback, index) => {
		const item = Array.isArray(src.envelopes) ? asRecord(src.envelopes[index]) : null;
		if (!item) return { ...fallback };
		return {
			label: typeof item.label === "string" ? item.label.slice(0, 600) : fallback.label,
			body: typeof item.body === "string" ? item.body.slice(0, TEXT_LIMIT) : fallback.body
		};
	});
	next.cinema = DEFAULTS.cinema.map((fallback, index) => {
		const item = Array.isArray(src.cinema) ? asRecord(src.cinema[index]) : null;
		if (!item) return { ...fallback };
		return {
			title: typeof item.title === "string" ? item.title.slice(0, 600) : fallback.title,
			body: typeof item.body === "string" ? item.body.slice(0, TEXT_LIMIT) : fallback.body,
			link: item.link === void 0 ? fallback.link : safeUrl(item.link),
			linkLabel: typeof item.linkLabel === "string" ? item.linkLabel.slice(0, 200) : fallback.linkLabel
		};
	});
	return next;
}
function freshState() {
	return {
		content: structuredClone(DEFAULTS),
		revision: 0,
		updatedAt: "",
		musicAt: null,
		photo1At: null,
		photo2At: null
	};
}
function signature(snapshot) {
	return [
		snapshot.revision,
		snapshot.updatedAt,
		snapshot.musicAt ?? "",
		snapshot.photo1At ?? "",
		snapshot.photo2At ?? ""
	].join("|");
}
var STAR_POS = [
	{
		x: 14,
		y: 62
	},
	{
		x: 32,
		y: 28
	},
	{
		x: 50,
		y: 70
	},
	{
		x: 68,
		y: 26
	},
	{
		x: 86,
		y: 56
	}
];
function heartPoints(count = 42) {
	const points = [];
	for (let i = 0; i < count; i += 1) {
		const t = i / count * Math.PI * 2;
		const x = 16 * Math.sin(t) ** 3;
		const y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t));
		points.push({
			x,
			y
		});
	}
	return points;
}
//#endregion
export { heartPoints as a, freshState as i, __exportAll as n, sanitize as o, content_DHthi_kq_exports as r, signature as s, STAR_POS as t };
