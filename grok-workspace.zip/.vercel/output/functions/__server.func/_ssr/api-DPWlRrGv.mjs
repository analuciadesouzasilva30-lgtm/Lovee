import { i as freshState, o as sanitize } from "./content-DHthi_kq.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { t as getSql } from "./db-B9adYO-Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DPWlRrGv.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var AUDIO = /* @__PURE__ */ new Set([
	"audio/mpeg",
	"audio/mp3",
	"audio/mp4",
	"audio/aac",
	"audio/ogg",
	"audio/wav",
	"audio/x-wav",
	"audio/webm"
]);
var IMAGES = /* @__PURE__ */ new Set([
	"image/jpeg",
	"image/png",
	"image/webp"
]);
function stamp(value) {
	if (value instanceof Date) return value.toISOString();
	if (typeof value === "string" && value) {
		const parsed = new Date(value);
		if (!Number.isNaN(parsed.getTime())) return parsed.toISOString();
	}
	return (/* @__PURE__ */ new Date()).toISOString();
}
async function ensureDocument(sql) {
	const { DEFAULTS } = await import("./content-DHthi_kq.mjs").then((n) => n.r).then((n) => n.n);
	await sql.query(`insert into sky_document (id, payload)
     values (1, $1)
     on conflict (id) do nothing`, [JSON.stringify(DEFAULTS)]);
}
async function readState(sql) {
	await ensureDocument(sql);
	const doc = (await sql.query("select payload, revision, updated_at from sky_document where id = 1"))[0];
	if (!doc) return freshState();
	let parsed = {};
	try {
		parsed = JSON.parse(doc.payload);
	} catch {
		parsed = {};
	}
	const media = await sql.query("select key, updated_at from sky_media");
	const at = (key) => {
		const row = media.find((item) => item.key === key);
		return row ? stamp(row.updated_at) : null;
	};
	return {
		content: sanitize(parsed),
		revision: Number(doc.revision) || 1,
		updatedAt: stamp(doc.updated_at),
		musicAt: at("music"),
		photo1At: at("photo1"),
		photo2At: at("photo2")
	};
}
async function authorize(password) {
	const { passwordMatches } = await import("./guard.server-C61AuRsF.mjs");
	if (passwordMatches(password)) return null;
	await new Promise((resolve) => setTimeout(resolve, 450));
	return "Senha incorreta.";
}
function readPassword(input) {
	if (!input || typeof input !== "object") return null;
	const password = input.password;
	if (typeof password !== "string" || password.length > 200) return null;
	return password;
}
var getSky_createServerFn_handler = createServerRpc({
	id: "3421445504df3e863f99b5072e92ce6622cfb25f83eedccffffd5bf7c3e13873",
	name: "getSky",
	filename: "src/sky/api.ts"
}, (opts) => getSky.__executeServer(opts));
var getSky = createServerFn({ method: "GET" }).handler(getSky_createServerFn_handler, async () => {
	return readState(await getSql());
});
var checkAdmin_createServerFn_handler = createServerRpc({
	id: "349500d29b75c9d3f26b44c6d6ef708f0c2b8cd0259bd215c272fdc65cc8d581",
	name: "checkAdmin",
	filename: "src/sky/api.ts"
}, (opts) => checkAdmin.__executeServer(opts));
var checkAdmin = createServerFn({ method: "POST" }).validator((input) => {
	const password = readPassword(input);
	if (password === null) throw new Error("Senha inválida.");
	return { password };
}).handler(checkAdmin_createServerFn_handler, async ({ data }) => {
	const error = await authorize(data.password);
	if (error) return {
		ok: false,
		error
	};
	return { ok: true };
});
var saveSky_createServerFn_handler = createServerRpc({
	id: "22d145b731c9151c856657c5c9de63134335226c2716fff36d0619693005a538",
	name: "saveSky",
	filename: "src/sky/api.ts"
}, (opts) => saveSky.__executeServer(opts));
var saveSky = createServerFn({ method: "POST" }).validator((input) => {
	const password = readPassword(input);
	if (password === null) throw new Error("Senha inválida.");
	return {
		password,
		content: sanitize(input.content)
	};
}).handler(saveSky_createServerFn_handler, async ({ data }) => {
	const error = await authorize(data.password);
	if (error) return {
		ok: false,
		error
	};
	const sql = await getSql();
	await ensureDocument(sql);
	await sql.query(`update sky_document
       set payload = $1, revision = revision + 1, updated_at = now()
       where id = 1`, [JSON.stringify(data.content)]);
	return {
		ok: true,
		...await readState(sql)
	};
});
function mediaKey(value) {
	if (value === "music" || value === "photo1" || value === "photo2") return value;
	return null;
}
var saveMedia_createServerFn_handler = createServerRpc({
	id: "e5f7bd0d6fd321dbb2b6a3fb95fe385b0350496ca3025fdd9a28f14abb967ad2",
	name: "saveMedia",
	filename: "src/sky/api.ts"
}, (opts) => saveMedia.__executeServer(opts));
var saveMedia = createServerFn({ method: "POST" }).validator((input) => {
	const password = readPassword(input);
	if (password === null) throw new Error("Senha inválida.");
	const record = input;
	const key = mediaKey(record.key);
	if (!key) throw new Error("Arquivo inválido.");
	return {
		password,
		key,
		mime: typeof record.mime === "string" ? record.mime.slice(0, 120) : "",
		data: typeof record.data === "string" ? record.data : ""
	};
}).handler(saveMedia_createServerFn_handler, async ({ data }) => {
	const error = await authorize(data.password);
	if (error) return {
		ok: false,
		error
	};
	const sql = await getSql();
	await ensureDocument(sql);
	if (!data.data) await sql.query("delete from sky_media where key = $1", [data.key]);
	else {
		if (!(data.key === "music" ? AUDIO : IMAGES).has(data.mime)) return {
			ok: false,
			error: "Esse formato não pode entrar no céu."
		};
		if (Math.floor(data.data.length * 3 / 4) > (data.key === "music" ? 2e6 : 7e5) || data.data.length > (data.key === "music" ? 3e6 : 12e5)) return {
			ok: false,
			error: data.key === "music" ? "O áudio precisa ter até 2 MB." : "A foto precisa ter até 700 KB."
		};
		await sql.query(`insert into sky_media (key, mime, data, updated_at)
         values ($1, $2, $3, now())
         on conflict (key) do update
         set mime = excluded.mime, data = excluded.data, updated_at = now()`, [
			data.key,
			data.mime,
			data.data
		]);
	}
	await sql.query("update sky_document set revision = revision + 1, updated_at = now() where id = 1");
	return {
		ok: true,
		...await readState(sql)
	};
});
//#endregion
export { checkAdmin_createServerFn_handler, getSky_createServerFn_handler, saveMedia_createServerFn_handler, saveSky_createServerFn_handler };
