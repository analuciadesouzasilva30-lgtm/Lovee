create table if not exists sky_document (
  id integer primary key,
  payload text not null,
  revision integer not null default 1,
  updated_at timestamptz not null default now(),
  constraint sky_document_singleton check (id = 1)
);

create table if not exists sky_media (
  key text primary key,
  mime text not null,
  data text not null,
  updated_at timestamptz not null default now()
);
