import { BookOpen, Moon, Sparkles, Square, Play } from "lucide-react";
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { checkAdmin, getSky, saveMedia, saveSky } from "@/sky/api";
import {
  signature,
  type SkyContent,
  type SkySnapshot,
} from "@/sky/content";
import {
  Constellation,
  EnvelopeGraphic,
  GlassBox,
  HeartSky,
  NightMap,
  Panorama,
  TwoSkies,
} from "@/sky/scenes";

type TextKey = {
  [K in keyof SkyContent]: SkyContent[K] extends string ? K : never;
}[keyof SkyContent];

const NAV = [
  ["ceu", "Céu"],
  ["carta", "Carta"],
  ["estrelas", "Estrelas"],
  ["juntos", "Juntos"],
  ["palavras", "Palavras"],
  ["cinema", "Cinema"],
  ["capsula", "Cápsula"],
  ["mapa", "Mapa"],
] as const;

const GROUPS: { title: string; fields: { key: TextKey; label: string; rows?: number }[] }[] = [
  {
    title: "Nomes",
    fields: [
      { key: "siteTitle", label: "Nome deste lugar" },
      { key: "myName", label: "Seu nome ou apelido" },
      { key: "theirName", label: "Nome ou apelido da pessoa" },
      { key: "signature", label: "Assinatura" },
    ],
  },
  {
    title: "Abertura",
    fields: [
      { key: "introLine", label: "Frase da abertura", rows: 4 },
      { key: "introButton", label: "Botão da abertura" },
    ],
  },
  {
    title: "Página principal",
    fields: [
      { key: "homeQuote", label: "Frase central", rows: 4 },
      { key: "homeSub", label: "Mensagem menor", rows: 3 },
      { key: "openLetterLabel", label: "Botão da carta" },
      { key: "exploreLabel", label: "Botão de explorar" },
    ],
  },
  {
    title: "Carta principal",
    fields: [
      { key: "letterKicker", label: "Título da carta" },
      { key: "letter", label: "Texto da carta", rows: 12 },
    ],
  },
  {
    title: "Céu compartilhado",
    fields: [
      { key: "sharedKicker", label: "Título" },
      { key: "sharedLine", label: "Frase", rows: 3 },
      { key: "sharedButton", label: "Botão" },
      { key: "sharedAfter", label: "Mensagem depois de acender", rows: 4 },
      { key: "sharedNote", label: "Nota simbólica" },
    ],
  },
  {
    title: "Palavras guardadas",
    fields: [{ key: "wordsTitle", label: "Título da seção" }],
  },
  {
    title: "Cinema",
    fields: [{ key: "cinemaTitle", label: "Título da seção" }],
  },
  {
    title: "Cápsula",
    fields: [
      { key: "capsuleTitle", label: "Título" },
      { key: "capsuleIntro", label: "Introdução", rows: 3 },
      { key: "capsuleFutureLabel", label: "Rótulo do futuro" },
      { key: "capsuleFuture", label: "Mensagem para o futuro", rows: 4 },
      { key: "capsulePresentLabel", label: "Rótulo do presente" },
      { key: "capsulePresent", label: "Lembrança do presente", rows: 4 },
      { key: "capsuleLearnLabel", label: "Rótulo do que quer conhecer" },
      { key: "capsuleLearn", label: "O que quer conhecer", rows: 4 },
      { key: "capsuleWishLabel", label: "Rótulo do desejo" },
      { key: "capsuleWish", label: "Desejo para o próximo momento", rows: 4 },
    ],
  },
  {
    title: "Mapa",
    fields: [
      { key: "mapTitle", label: "Título" },
      { key: "mapCenter", label: "Frase do centro", rows: 3 },
      { key: "myPlaceName", label: "Nome do seu lugar" },
      { key: "theirPlaceName", label: "Nome do lugar dela" },
      { key: "myWorldLabel", label: "Rótulo do seu mundo" },
      { key: "myWorld", label: "Texto do seu mundo", rows: 4 },
      { key: "theirWorldLabel", label: "Rótulo do mundo dela" },
      { key: "theirWorld", label: "Texto do mundo dela", rows: 4 },
    ],
  },
  {
    title: "Surpresa final",
    fields: [
      { key: "finaleButton", label: "Botão que revela" },
      { key: "finale1", label: "Primeira mensagem", rows: 4 },
      { key: "finale2", label: "Segunda mensagem", rows: 4 },
      { key: "finaleBack", label: "Botão de voltar" },
    ],
  },
  {
    title: "Música",
    fields: [
      { key: "musicTitle", label: "Nome que aparece no botão" },
      { key: "musicUrl", label: "Link direto do áudio (opcional, https)" },
    ],
  },
];

function Prose({ text }: { text: string }) {
  const parts = text.split(/\n{2,}/).filter((part) => part.trim().length > 0);
  if (!parts.length) return null;
  return parts.map((part, index) => <p key={index}>{part}</p>);
}

function Paper({
  kicker,
  title,
  closeLabel,
  onClose,
  children,
}: {
  kicker?: string;
  title?: string;
  closeLabel: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <article className="paper appear">
      {kicker ? <p className="kicker on-paper">{kicker}</p> : null}
      {title ? <h3>{title}</h3> : null}
      <div className="paper-body">{children}</div>
      <button type="button" className="btn ghost dark" onClick={onClose}>
        {closeLabel}
      </button>
    </article>
  );
}

function Signoff({ content }: { content: SkyContent }) {
  return (
    <footer className="signoff">
      {content.theirName ? <p>Para {content.theirName}</p> : null}
      <p className="sign-row">
        <svg viewBox="0 0 24 24" className="sig-star" aria-hidden="true">
          <path d="M12 0 13.8 8.4 22 12 13.8 15.6 12 24 10.2 15.6 2 12 10.2 8.4Z" />
        </svg>
        <span>
          {content.signature}
          {content.myName ? ` · ${content.myName}` : ""}
        </span>
      </p>
    </footer>
  );
}

function Photo({
  which,
  at,
  alt,
}: {
  which: "photo1" | "photo2";
  at: string | null;
  alt: string;
}) {
  if (!at) return null;
  return (
    <figure className="photo-frame">
      <img src={`/api/media?key=${which}&v=${encodeURIComponent(at)}`} alt={alt} />
    </figure>
  );
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const value = String(reader.result ?? "");
      const index = value.indexOf(",");
      resolve(index >= 0 ? value.slice(index + 1) : value);
    };
    reader.onerror = () => reject(new Error("read"));
    reader.readAsDataURL(file);
  });
}

function guessMime(file: File, kind: "audio" | "image"): string | null {
  const known =
    kind === "audio"
      ? ["audio/mpeg", "audio/mp3", "audio/mp4", "audio/aac", "audio/ogg", "audio/wav", "audio/x-wav", "audio/webm"]
      : ["image/jpeg", "image/png", "image/webp"];
  if (known.includes(file.type)) return file.type === "audio/mp3" ? "audio/mpeg" : file.type;
  const name = file.name.toLowerCase();
  if (kind === "audio") {
    if (name.endsWith(".mp3")) return "audio/mpeg";
    if (name.endsWith(".m4a")) return "audio/mp4";
    if (name.endsWith(".ogg")) return "audio/ogg";
    if (name.endsWith(".wav")) return "audio/wav";
    if (name.endsWith(".webm")) return "audio/webm";
  } else {
    if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
    if (name.endsWith(".png")) return "image/png";
    if (name.endsWith(".webp")) return "image/webp";
  }
  return null;
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function Starfield() {
  const rand = mulberry32(20261015);
  const stars = Array.from({ length: 120 }, () => ({
    left: rand() * 100,
    top: rand() * 100,
    size: rand() * 2.1 + 0.8,
    delay: rand() * 5,
    dur: 2.4 + rand() * 3.6,
    opacity: 0.35 + rand() * 0.65,
  }));
  const petals = Array.from({ length: 11 }, () => ({
    left: rand() * 100,
    delay: rand() * 14,
    dur: 16 + rand() * 14,
    size: 7 + rand() * 8,
    drift: -40 + rand() * 80,
  }));
  return (
    <div className="starfield" aria-hidden="true">
      {stars.map((star, index) => (
        <span
          key={index}
          className="sky-star"
          style={{
            left: `${star.left}%`,
            top: `${star.top}%`,
            width: star.size,
            height: star.size,
            opacity: star.opacity,
            animationDelay: `${star.delay}s`,
            animationDuration: `${star.dur}s`,
          }}
        />
      ))}
      {petals.map((petal, index) => (
        <span
          key={`p-${index}`}
          className="petal"
          style={{
            left: `${petal.left}%`,
            width: petal.size,
            height: petal.size * 0.5,
            animationDelay: `${petal.delay}s`,
            animationDuration: `${petal.dur}s`,
            ["--drift" as string]: `${petal.drift}px`,
          }}
        />
      ))}
    </div>
  );
}

function PointerDust() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    function live() {
      return !document.querySelector(".page.motion-off");
    }
    function onMove(event: PointerEvent) {
      if (!live() || event.pointerType === "touch" || !root) return;
      const dot = document.createElement("span");
      dot.className = "dust";
      dot.style.left = `${event.clientX}px`;
      dot.style.top = `${event.clientY}px`;
      root.appendChild(dot);
      window.setTimeout(() => dot.remove(), 650);
    }
    function onDown(event: PointerEvent) {
      if (!live() || event.pointerType !== "touch" || !root) return;
      const ring = document.createElement("span");
      ring.className = "touch-ring";
      ring.style.left = `${event.clientX}px`;
      ring.style.top = `${event.clientY}px`;
      root.appendChild(ring);
      window.setTimeout(() => ring.remove(), 750);
    }
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerdown", onDown);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerdown", onDown);
    };
  }, []);
  return <div ref={ref} className="dust-layer" aria-hidden="true" />;
}

export function Experience({ initial }: { initial: SkySnapshot }) {
  const [snap, setSnap] = useState(initial);
  const [draft, setDraft] = useState(initial.content);
  const [dirty, setDirty] = useState(false);
  const [seenRev, setSeenRev] = useState(initial.revision);
  const [phase, setPhase] = useState<"in" | "out" | "done">("in");
  const [motionOn, setMotionOn] = useState(true);
  const [reading, setReading] = useState(false);
  const [letterOpen, setLetterOpen] = useState(false);
  const [star, setStar] = useState<number | null>(null);
  const [envelope, setEnvelope] = useState<number | null>(null);
  const [litKey, setLitKey] = useState(0);
  const [capsule, setCapsule] = useState(false);
  const [mapPoint, setMapPoint] = useState<"mine" | "theirs" | null>(null);
  const [finale, setFinale] = useState(false);
  const [finaleStep, setFinaleStep] = useState(0);
  const [active, setActive] = useState("ceu");
  const [musicState, setMusicState] = useState<"idle" | "loading" | "on">("idle");
  const [musicHint, setMusicHint] = useState("");
  const [syncNote, setSyncNote] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [password, setPassword] = useState("");
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState<string | null>(null);
  const [adminMsg, setAdminMsg] = useState("");
  const audioRef = useRef<HTMLAudioElement>(null);
  const musicFileRef = useRef<HTMLInputElement>(null);
  const photo1Ref = useRef<HTMLInputElement>(null);
  const photo2Ref = useRef<HTMLInputElement>(null);
  const selfRev = useRef<number | null>(null);
  const snapRef = useRef(snap);
  snapRef.current = snap;
  const content = snap.content;

  useEffect(() => {
    const motion = localStorage.getItem("ceu-motion");
    const read = localStorage.getItem("ceu-reading");
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (motion === "off" || (reduce && motion !== "on")) setMotionOn(false);
    if (read === "on") setReading(true);
  }, []);

  useEffect(() => {
    if (dirty) return;
    setDraft((prev) => (JSON.stringify(prev) === JSON.stringify(snap.content) ? prev : snap.content));
    setSeenRev(snap.revision);
  }, [snap, dirty]);

  useEffect(() => {
    let cancel = false;
    let timer = 0;
    async function pull() {
      if (cancel || document.hidden) return;
      try {
        const next = await getSky();
        if (cancel) return;
        const prev = snapRef.current;
        if (signature(prev) === signature(next)) return;
        const external = next.revision !== prev.revision && next.revision !== selfRev.current;
        setSnap(next);
        if (external) {
          setSyncNote(true);
          window.setTimeout(() => setSyncNote(false), 2800);
        }
      } catch {
        /* keep the last sky */
      }
    }
    function loop() {
      timer = window.setTimeout(async () => {
        await pull();
        if (!cancel) loop();
      }, 3000);
    }
    loop();
    const onVis = () => {
      if (!document.hidden) void pull();
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("focus", onVis);
    return () => {
      cancel = true;
      window.clearTimeout(timer);
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("focus", onVis);
    };
  }, []);

  useEffect(() => {
    if (!finale) {
      setFinaleStep(0);
      return;
    }
    const first = window.setTimeout(() => setFinaleStep(1), motionOn ? 900 : 0);
    const second = window.setTimeout(() => setFinaleStep(2), motionOn ? 2600 : 0);
    return () => {
      window.clearTimeout(first);
      window.clearTimeout(second);
    };
  }, [finale, motionOn]);

  useEffect(() => {
    const key = `${snap.musicAt ?? ""}|${snap.content.musicUrl}`;
    const audio = audioRef.current;
    if (!audio) return;
    if (audio.dataset.key && audio.dataset.key !== key && musicState === "on") {
      audio.pause();
      setMusicState("idle");
      setMusicHint("A música foi atualizada. Toque de novo se quiser ouvir.");
    }
    audio.dataset.key = key;
  }, [snap.musicAt, snap.content.musicUrl, musicState]);

  useEffect(() => {
    const nodes = NAV.map(([id]) => document.getElementById(id)).filter(
      (node): node is HTMLElement => Boolean(node),
    );
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-35% 0px -45% 0px", threshold: [0.15, 0.4] },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!adminOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, [adminOpen]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key !== "Escape") return;
      if (adminOpen) {
        setAdminOpen(false);
        return;
      }
      setLetterOpen(false);
      setStar(null);
      setEnvelope(null);
      setCapsule(false);
      setMapPoint(null);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [adminOpen]);

  function go(id: string) {
    document.getElementById(id)?.scrollIntoView({
      behavior: motionOn ? "smooth" : "auto",
      block: "start",
    });
  }

  function closeIntro() {
    if (phase !== "in") return;
    if (!motionOn) {
      setPhase("done");
      return;
    }
    setPhase("out");
    window.setTimeout(() => setPhase("done"), 700);
  }

  function musicSource() {
    if (snap.musicAt) return `/api/media?key=music&v=${encodeURIComponent(snap.musicAt)}`;
    return content.musicUrl;
  }

  async function toggleMusic() {
    const audio = audioRef.current;
    if (!audio) return;
    if (musicState !== "idle") {
      audio.pause();
      audio.currentTime = 0;
      setMusicState("idle");
      return;
    }
    const src = musicSource();
    if (!src) {
      setMusicHint("A música ainda não foi colocada neste céu. O botão fica pronto para quando ela chegar.");
      return;
    }
    setMusicHint("");
    setMusicState("loading");
    const absolute = new URL(src, window.location.href).href;
    if (audio.src !== absolute) audio.src = src;
    try {
      await audio.play();
      setMusicState("on");
    } catch {
      setMusicState("idle");
      setMusicHint("Não consegui tocar agora. Tenta de novo em um instante.");
    }
  }

  function setText(key: TextKey, value: string) {
    setDirty(true);
    setDraft((prev) => ({ ...prev, [key]: value }));
  }

  async function unlock(event: FormEvent) {
    event.preventDefault();
    setChecking(true);
    setAdminMsg("");
    try {
      const result = await checkAdmin({ data: { password } });
      if (!result.ok) {
        setAdminMsg(result.error);
        return;
      }
      setUnlocked(true);
    } catch {
      setAdminMsg("Não consegui confirmar agora.");
    } finally {
      setChecking(false);
    }
  }

  async function onSave(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    setAdminMsg("");
    try {
      const result = await saveSky({ data: { password, content: draft } });
      if (!result.ok) {
        setAdminMsg(result.error);
        return;
      }
      selfRev.current = result.revision;
      setSnap(result);
      setDraft(result.content);
      setDirty(false);
      setSeenRev(result.revision);
      setAdminMsg("Guardado. Quem abrir o site, de qualquer lugar, passa a ver esta versão.");
    } catch {
      setAdminMsg("Não consegui sincronizar agora. Tenta de novo.");
    } finally {
      setSaving(false);
    }
  }

  async function onFile(kind: "music" | "photo1" | "photo2", file: File | undefined) {
    if (!file) return;
    const mime = guessMime(file, kind === "music" ? "audio" : "image");
    if (!mime) {
      setAdminMsg("Usa MP3, M4A, OGG, WAV ou uma foto JPG, PNG ou WebP.");
      return;
    }
    const max = kind === "music" ? 2_000_000 : 700_000;
    if (file.size > max) {
      setAdminMsg(kind === "music" ? "O áudio precisa ter até 2 MB." : "A foto precisa ter até 700 KB.");
      return;
    }
    setUploading(kind);
    setAdminMsg("");
    try {
      const data = await fileToBase64(file);
      const result = await saveMedia({ data: { password, key: kind, mime, data } });
      if (!result.ok) {
        setAdminMsg(result.error);
        return;
      }
      selfRev.current = result.revision;
      setSnap(result);
      setSeenRev(result.revision);
      setAdminMsg(kind === "music" ? "Música guardada para todo mundo." : "Fotografia guardada para todo mundo.");
    } catch {
      setAdminMsg("Não consegui enviar o arquivo agora.");
    } finally {
      setUploading(null);
    }
  }

  async function clearMedia(kind: "music" | "photo1" | "photo2") {
    setUploading(kind);
    setAdminMsg("");
    try {
      const result = await saveMedia({ data: { password, key: kind, mime: "", data: "" } });
      if (!result.ok) {
        setAdminMsg(result.error);
        return;
      }
      selfRev.current = result.revision;
      setSnap(result);
      setSeenRev(result.revision);
      if (kind === "music") {
        audioRef.current?.pause();
        setMusicState("idle");
      }
      setAdminMsg("Removido para todo mundo.");
    } catch {
      setAdminMsg("Não consegui remover agora.");
    } finally {
      setUploading(null);
    }
  }

  const openStar = star !== null ? content.stars[star] : null;
  const openEnvelope = envelope !== null ? content.envelopes[envelope] : null;

  return (
    <div className={`page ${motionOn ? "" : "motion-off"} ${reading ? "reading" : ""}`}>
      <div className="nebula" aria-hidden="true" />
      <Starfield />
      <PointerDust />
      <audio
        ref={audioRef}
        preload="none"
        onEnded={() => setMusicState("idle")}
      />

      <button type="button" className="secret-star" aria-label="Canto reservado" onClick={() => setAdminOpen(true)}>
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 1.4 14.2 8.8 21.8 9.4 16 14.2 17.8 21.6 12 17.6 6.2 21.6 8 14.2 2.2 9.4 9.8 8.8Z" />
        </svg>
      </button>

      {phase !== "done" ? (
        <div className={`intro ${phase === "out" ? "intro-out" : ""}`}>
          <button type="button" className="skip" onClick={closeIntro}>
            Pular introdução
          </button>
          <div className="intro-card">
            <p className="kicker">{content.siteTitle}</p>
            <svg className="intro-const" viewBox="0 0 220 90" aria-hidden="true">
              <line x1="48" y1="58" x2="172" y2="34" className="draw-line" />
              <circle cx="48" cy="58" r="3.2" className="intro-star a" />
              <circle cx="172" cy="34" r="3.2" className="intro-star b" />
            </svg>
            <p className="intro-copy">{content.introLine}</p>
            <button type="button" className="btn solid intro-copy late" onClick={closeIntro}>
              {content.introButton}
            </button>
          </div>
        </div>
      ) : null}

      {phase !== "in" ? (
        <div className="top-tools">
          <button
            type="button"
            aria-pressed={reading}
            aria-label={reading ? "Desativar modo de leitura" : "Ativar modo de leitura"}
            onClick={() =>
              setReading((value) => {
                localStorage.setItem("ceu-reading", value ? "off" : "on");
                return !value;
              })
            }
          >
            <BookOpen />
          </button>
          <button
            type="button"
            aria-pressed={motionOn}
            aria-label={motionOn ? "Desativar animações" : "Ativar animações"}
            onClick={() =>
              setMotionOn((value) => {
                localStorage.setItem("ceu-motion", value ? "off" : "on");
                return !value;
              })
            }
          >
            {motionOn ? <Sparkles /> : <Moon />}
          </button>
        </div>
      ) : null}

      {syncNote ? (
        <p className="sync-pill" role="status">
          O céu foi atualizado
        </p>
      ) : null}

      <main className={phase === "in" ? "held" : "shown"} inert={phase === "in" ? true : undefined}>
        <section id="ceu" className="block hero">
          <p className="kicker">{content.siteTitle}</p>
          <Panorama motionOn={motionOn} />
          <div className="glass quote">
            <h1>{content.homeQuote}</h1>
            <p>{content.homeSub}</p>
          </div>
          <div className="action-row">
            <button
              type="button"
              className="btn solid"
              onClick={() => {
                setLetterOpen(true);
                go("carta");
              }}
            >
              {content.openLetterLabel}
            </button>
            <button type="button" className="btn ghost" onClick={() => go("estrelas")}>
              {content.exploreLabel}
            </button>
          </div>
        </section>

        <section id="carta" className="block">
          <p className="kicker">{content.letterKicker}</p>
          <h2>Palavras que atravessam quilômetros</h2>
          <button
            type="button"
            className="env-hit"
            aria-expanded={letterOpen}
            onClick={() => setLetterOpen(true)}
          >
            <EnvelopeGraphic open={letterOpen} />
            <span className="sr-only">Abrir a carta</span>
          </button>
          {letterOpen ? (
            <Paper kicker="Carta" closeLabel="Fechar a carta" onClose={() => setLetterOpen(false)}>
              <Prose text={content.letter} />
              <Signoff content={content} />
              <Photo which="photo1" at={snap.photo1At} alt="Fotografia deixada junto da carta" />
            </Paper>
          ) : (
            <p className="hint">O envelope espera por um toque.</p>
          )}
        </section>

        <section id="estrelas" className="block">
          <p className="kicker">Constelação</p>
          <h2>{content.starsTitle}</h2>
          <p className="lede">Cinco estrelas. Nenhuma se abre sozinha.</p>
          <Constellation
            active={star}
            onPick={(index) => setStar((current) => (current === index ? null : index))}
          />
          {openStar ? (
            <Paper
              kicker={`Estrela ${star! + 1}`}
              title={openStar.title}
              closeLabel="Fechar estrela"
              onClose={() => setStar(null)}
            >
              <Prose text={openStar.body} />
            </Paper>
          ) : null}
        </section>

        <section id="juntos" className="block">
          <p className="kicker">{content.sharedKicker}</p>
          <h2>O mesmo gesto, em dois céus</h2>
          <TwoSkies
            litKey={litKey}
            left={content.myPlaceName}
            right={content.theirPlaceName}
            motionOn={motionOn}
          />
          <p className="lede quote-line">{content.sharedLine}</p>
          <button type="button" className="btn solid" onClick={() => setLitKey((value) => value + 1)}>
            {content.sharedButton}
          </button>
          {litKey > 0 ? (
            <div className="glass after appear">
              <Prose text={content.sharedAfter} />
            </div>
          ) : null}
          <p className="hint">{content.sharedNote}</p>
        </section>

        <section id="palavras" className="block">
          <p className="kicker">Envelopes</p>
          <h2>{content.wordsTitle}</h2>
          <div className="envelope-grid">
            {content.envelopes.map((item, index) => (
              <button
                key={item.label}
                type="button"
                className={`mini-env ${envelope === index ? "is-on" : ""}`}
                aria-expanded={envelope === index}
                onClick={() => setEnvelope(index)}
              >
                <EnvelopeGraphic open={envelope === index} />
                <span>{item.label}</span>
              </button>
            ))}
          </div>
          {openEnvelope ? (
            <Paper
              title={openEnvelope.label}
              closeLabel="Fechar e voltar aos envelopes"
              onClose={() => setEnvelope(null)}
            >
              <Prose text={openEnvelope.body} />
            </Paper>
          ) : null}
        </section>

        <section id="cinema" className="block">
          <p className="kicker">À distância</p>
          <h2>{content.cinemaTitle}</h2>
          <div className="screen" aria-hidden="true">
            <span>a tela acende quando a gente combina</span>
          </div>
          <Photo which="photo2" at={snap.photo2At} alt="Fotografia deixada na sala de cinema" />
          <div className="card-grid">
            {content.cinema.map((card) => (
              <article key={card.title} className="glass cinema-card">
                <h3>{card.title}</h3>
                <Prose text={card.body} />
                {card.link ? (
                  <a href={card.link} target="_blank" rel="noreferrer">
                    {card.linkLabel || "Abrir"}
                  </a>
                ) : null}
              </article>
            ))}
          </div>
        </section>

        <section id="capsula" className="block">
          <p className="kicker">Continuidade</p>
          <h2>{content.capsuleTitle}</h2>
          <p className="lede">{content.capsuleIntro}</p>
          <button
            type="button"
            className="box-hit"
            aria-expanded={capsule}
            onClick={() => setCapsule(true)}
          >
            <GlassBox open={capsule} />
            <span className="sr-only">Abrir a cápsula</span>
          </button>
          {capsule ? (
            <Paper closeLabel="Fechar a cápsula" onClose={() => setCapsule(false)}>
              <h3>{content.capsuleFutureLabel}</h3>
              <Prose text={content.capsuleFuture} />
              <h3>{content.capsulePresentLabel}</h3>
              <Prose text={content.capsulePresent} />
              <h3>{content.capsuleLearnLabel}</h3>
              <Prose text={content.capsuleLearn} />
              <h3>{content.capsuleWishLabel}</h3>
              <Prose text={content.capsuleWish} />
            </Paper>
          ) : (
            <p className="hint">A caixa fica fechada até você querer abri-la.</p>
          )}
        </section>

        <section id="mapa" className="block">
          <p className="kicker">Dois mundos</p>
          <h2>{content.mapTitle}</h2>
          <NightMap
            mine={content.myPlaceName}
            theirs={content.theirPlaceName}
            onMine={() => setMapPoint("mine")}
            onTheirs={() => setMapPoint("theirs")}
          />
          <p className="lede quote-line">{content.mapCenter}</p>
          {mapPoint ? (
            <Paper
              title={mapPoint === "mine" ? content.myWorldLabel : content.theirWorldLabel}
              closeLabel="Fechar"
              onClose={() => setMapPoint(null)}
            >
              <Prose text={mapPoint === "mine" ? content.myWorld : content.theirWorld} />
            </Paper>
          ) : (
            <p className="hint">Toque nos dois pontos luminosos.</p>
          )}
        </section>

        <section id="final" className={`block finale ${finale ? "is-open" : ""}`}>
          {!finale ? (
            <button type="button" className="btn ghost finale-btn" onClick={() => setFinale(true)}>
              {content.finaleButton}
            </button>
          ) : (
            <>
              <HeartSky show={finale} />
              {finaleStep >= 1 ? <p className="finale-copy appear">{content.finale1}</p> : null}
              {finaleStep >= 2 ? (
                <>
                  <p className="finale-copy appear">{content.finale2}</p>
                  <Signoff content={content} />
                  <button
                    type="button"
                    className="btn ghost"
                    onClick={() => {
                      setFinale(false);
                      go("ceu");
                    }}
                  >
                    {content.finaleBack}
                  </button>
                </>
              ) : null}
            </>
          )}
        </section>

        <footer className="colophon">
          <p>Um lugar só nosso. Nada aqui pede cadastro.</p>
          <button type="button" className="text-link" onClick={() => go("ceu")}>
            Voltar ao início
          </button>
        </footer>
      </main>

      {phase !== "in" ? (
        <div className="dock">
          <button
            type="button"
            className={`music-btn ${musicState === "on" ? "is-on" : ""}`}
            onClick={() => void toggleMusic()}
            aria-pressed={musicState === "on"}
          >
            {musicState === "on" ? <Square /> : <Play />}
            <span>{musicState === "on" ? "Cancelar" : `Ouvir ${content.musicTitle}`}</span>
            {musicState === "on" ? <small>{content.musicTitle}</small> : null}
          </button>
          {musicHint ? (
            <p className="music-hint" role="status">
              {musicHint}
            </p>
          ) : null}
          <nav aria-label="Seções">
            {NAV.map(([id, label]) => (
              <button
                key={id}
                type="button"
                aria-current={active === id ? "true" : undefined}
                onClick={() => go(id)}
              >
                {label}
              </button>
            ))}
          </nav>
        </div>
      ) : null}

      {adminOpen ? (
        <div className="admin-layer">
          <button type="button" className="admin-backdrop" aria-label="Fechar o canto reservado" onClick={() => setAdminOpen(false)} />
          <aside className="admin-sheet" role="dialog" aria-modal="true" aria-labelledby="admin-title">
            <header className="admin-head">
              <div>
                <p className="kicker">Canto reservado</p>
                <h2 id="admin-title">O céu, por dentro</h2>
              </div>
              <button type="button" className="icon-x" aria-label="Fechar" onClick={() => setAdminOpen(false)}>
                ×
              </button>
            </header>
            {!unlocked ? (
              <form onSubmit={(event) => void unlock(event)} className="admin-lock">
                <p>
                  Se este céu é seu de escrever, entra. Se é seu de ler, pode voltar — nada se perde.
                </p>
                <label className="field" htmlFor="admin-pass">
                  <span>Senha</span>
                  <input
                    id="admin-pass"
                    type="password"
                    autoComplete="current-password"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                  />
                </label>
                <button type="submit" className="btn solid" disabled={checking}>
                  {checking ? "Conferindo…" : "Entrar"}
                </button>
                {adminMsg ? <p className="admin-msg">{adminMsg}</p> : null}
              </form>
            ) : (
              <form onSubmit={(event) => void onSave(event)} className="admin-form">
                <p className="hint light">
                  O que você guardar aqui aparece para qualquer pessoa que abrir o site, onde ela estiver.
                  A música não começa sozinha.
                </p>
                {dirty && snap.revision !== seenRev ? (
                  <p className="admin-msg">
                    Chegou uma versão mais nova de outro lugar. Salvar agora substitui essa versão.
                  </p>
                ) : null}
                {GROUPS.map((group) => (
                  <details key={group.title} open={group.title === "Nomes"}>
                    <summary>{group.title}</summary>
                    {group.fields.map((field) => (
                      <label key={field.key} className="field" htmlFor={`f-${field.key}`}>
                        <span>{field.label}</span>
                        {field.rows ? (
                          <textarea
                            id={`f-${field.key}`}
                            rows={field.rows}
                            value={draft[field.key]}
                            onChange={(event) => setText(field.key, event.target.value)}
                          />
                        ) : (
                          <input
                            id={`f-${field.key}`}
                            value={draft[field.key]}
                            onChange={(event) => setText(field.key, event.target.value)}
                          />
                        )}
                      </label>
                    ))}
                  </details>
                ))}
                <details>
                  <summary>Constelação</summary>
                  <label className="field" htmlFor="f-starsTitle">
                    <span>Título da seção</span>
                    <input
                      id="f-starsTitle"
                      value={draft.starsTitle}
                      onChange={(event) => setText("starsTitle", event.target.value)}
                    />
                  </label>
                  {draft.stars.map((item, index) => (
                    <div key={index} className="subblock">
                      <label className="field" htmlFor={`star-t-${index}`}>
                        <span>Estrela {index + 1} — título</span>
                        <input
                          id={`star-t-${index}`}
                          value={item.title}
                          onChange={(event) => {
                            const value = event.target.value;
                            setDirty(true);
                            setDraft((prev) => {
                              const stars = prev.stars.map((starNote, starIndex) =>
                                starIndex === index ? { ...starNote, title: value } : starNote,
                              ) as SkyContent["stars"];
                              return { ...prev, stars };
                            });
                          }}
                        />
                      </label>
                      <label className="field" htmlFor={`star-b-${index}`}>
                        <span>Estrela {index + 1} — texto</span>
                        <textarea
                          id={`star-b-${index}`}
                          rows={5}
                          value={item.body}
                          onChange={(event) => {
                            const value = event.target.value;
                            setDirty(true);
                            setDraft((prev) => {
                              const stars = prev.stars.map((starNote, starIndex) =>
                                starIndex === index ? { ...starNote, body: value } : starNote,
                              ) as SkyContent["stars"];
                              return { ...prev, stars };
                            });
                          }}
                        />
                      </label>
                    </div>
                  ))}
                </details>
                <details>
                  <summary>Quatro envelopes</summary>
                  {draft.envelopes.map((item, index) => (
                    <div key={index} className="subblock">
                      <label className="field" htmlFor={`env-l-${index}`}>
                        <span>Envelope {index + 1} — por fora</span>
                        <textarea
                          id={`env-l-${index}`}
                          rows={2}
                          value={item.label}
                          onChange={(event) => {
                            const value = event.target.value;
                            setDirty(true);
                            setDraft((prev) => {
                              const envelopes = prev.envelopes.map((note, noteIndex) =>
                                noteIndex === index ? { ...note, label: value } : note,
                              ) as SkyContent["envelopes"];
                              return { ...prev, envelopes };
                            });
                          }}
                        />
                      </label>
                      <label className="field" htmlFor={`env-b-${index}`}>
                        <span>Envelope {index + 1} — por dentro</span>
                        <textarea
                          id={`env-b-${index}`}
                          rows={5}
                          value={item.body}
                          onChange={(event) => {
                            const value = event.target.value;
                            setDirty(true);
                            setDraft((prev) => {
                              const envelopes = prev.envelopes.map((note, noteIndex) =>
                                noteIndex === index ? { ...note, body: value } : note,
                              ) as SkyContent["envelopes"];
                              return { ...prev, envelopes };
                            });
                          }}
                        />
                      </label>
                    </div>
                  ))}
                </details>
                <details>
                  <summary>Cartões do cinema e links</summary>
                  {draft.cinema.map((card, index) => (
                    <div key={index} className="subblock">
                      <label className="field" htmlFor={`cin-t-${index}`}>
                        <span>Cartão {index + 1} — título</span>
                        <input
                          id={`cin-t-${index}`}
                          value={card.title}
                          onChange={(event) => {
                            const value = event.target.value;
                            setDirty(true);
                            setDraft((prev) => {
                              const cinema = prev.cinema.map((item, itemIndex) =>
                                itemIndex === index ? { ...item, title: value } : item,
                              ) as SkyContent["cinema"];
                              return { ...prev, cinema };
                            });
                          }}
                        />
                      </label>
                      <label className="field" htmlFor={`cin-b-${index}`}>
                        <span>Cartão {index + 1} — texto</span>
                        <textarea
                          id={`cin-b-${index}`}
                          rows={4}
                          value={card.body}
                          onChange={(event) => {
                            const value = event.target.value;
                            setDirty(true);
                            setDraft((prev) => {
                              const cinema = prev.cinema.map((item, itemIndex) =>
                                itemIndex === index ? { ...item, body: value } : item,
                              ) as SkyContent["cinema"];
                              return { ...prev, cinema };
                            });
                          }}
                        />
                      </label>
                      <label className="field" htmlFor={`cin-u-${index}`}>
                        <span>Link opcional</span>
                        <input
                          id={`cin-u-${index}`}
                          value={card.link}
                          placeholder="https://"
                          onChange={(event) => {
                            const value = event.target.value;
                            setDirty(true);
                            setDraft((prev) => {
                              const cinema = prev.cinema.map((item, itemIndex) =>
                                itemIndex === index ? { ...item, link: value } : item,
                              ) as SkyContent["cinema"];
                              return { ...prev, cinema };
                            });
                          }}
                        />
                      </label>
                      <label className="field" htmlFor={`cin-ll-${index}`}>
                        <span>Texto do link</span>
                        <input
                          id={`cin-ll-${index}`}
                          value={card.linkLabel}
                          onChange={(event) => {
                            const value = event.target.value;
                            setDirty(true);
                            setDraft((prev) => {
                              const cinema = prev.cinema.map((item, itemIndex) =>
                                itemIndex === index ? { ...item, linkLabel: value } : item,
                              ) as SkyContent["cinema"];
                              return { ...prev, cinema };
                            });
                          }}
                        />
                      </label>
                    </div>
                  ))}
                </details>
                <details open>
                  <summary>Arquivo de música e fotografias</summary>
                  <p className="hint light">
                    O botão público se chama {content.musicTitle}. Envie um áudio que você tenha direito de
                    usar — de preferência MP3, até 2 MB — ou cole um link direto no campo de música e guarde
                    os textos. Fotos são opcionais, até 700 KB.
                  </p>
                  <div className="upload-row">
                    <button type="button" className="btn ghost" onClick={() => musicFileRef.current?.click()} disabled={uploading !== null}>
                      {uploading === "music" ? "Enviando…" : snap.musicAt ? "Trocar a música" : "Enviar música"}
                    </button>
                    {snap.musicAt ? (
                      <button type="button" className="btn ghost" onClick={() => void clearMedia("music")} disabled={uploading !== null}>
                        Tirar música
                      </button>
                    ) : null}
                    <input
                      ref={musicFileRef}
                      className="sr-only"
                      type="file"
                      accept="audio/mpeg,audio/mp4,audio/ogg,audio/wav,audio/webm,.mp3,.m4a,.ogg,.wav"
                      onChange={(event) => {
                        void onFile("music", event.target.files?.[0]);
                        event.target.value = "";
                      }}
                    />
                  </div>
                  <div className="upload-row">
                    <button type="button" className="btn ghost" onClick={() => photo1Ref.current?.click()} disabled={uploading !== null}>
                      {uploading === "photo1" ? "Enviando…" : "Foto da carta"}
                    </button>
                    {snap.photo1At ? (
                      <button type="button" className="btn ghost" onClick={() => void clearMedia("photo1")} disabled={uploading !== null}>
                        Tirar foto
                      </button>
                    ) : null}
                    <input
                      ref={photo1Ref}
                      className="sr-only"
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      onChange={(event) => {
                        void onFile("photo1", event.target.files?.[0]);
                        event.target.value = "";
                      }}
                    />
                  </div>
                  <div className="upload-row">
                    <button type="button" className="btn ghost" onClick={() => photo2Ref.current?.click()} disabled={uploading !== null}>
                      {uploading === "photo2" ? "Enviando…" : "Foto do cinema"}
                    </button>
                    {snap.photo2At ? (
                      <button type="button" className="btn ghost" onClick={() => void clearMedia("photo2")} disabled={uploading !== null}>
                        Tirar foto
                      </button>
                    ) : null}
                    <input
                      ref={photo2Ref}
                      className="sr-only"
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      onChange={(event) => {
                        void onFile("photo2", event.target.files?.[0]);
                        event.target.value = "";
                      }}
                    />
                  </div>
                  <Photo which="photo1" at={snap.photo1At} alt="Prévia da fotografia da carta" />
                  <Photo which="photo2" at={snap.photo2At} alt="Prévia da fotografia do cinema" />
                </details>
                <div className="save-bar">
                  <button type="submit" className="btn solid" disabled={saving}>
                    {saving ? "Guardando…" : "Guardar neste céu"}
                  </button>
                  {adminMsg ? (
                    <p className="admin-msg" role="status">
                      {adminMsg}
                    </p>
                  ) : null}
                  {snap.updatedAt ? (
                    <p className="hint light">
                      Última sincronização:{" "}
                      {new Date(snap.updatedAt).toLocaleString("pt-BR", {
                        dateStyle: "short",
                        timeStyle: "short",
                      })}
                    </p>
                  ) : null}
                </div>
              </form>
            )}
          </aside>
        </div>
      ) : null}
    </div>
  );
}
