import { timingSafeEqual } from "node:crypto";

/** Shared writing key for the hidden panel. Not exported to the client. */
export function passwordMatches(password: string): boolean {
  const given = Buffer.from(password);
  const expected = Buffer.from("love123");
  if (given.length !== expected.length) return false;
  return timingSafeEqual(given, expected);
}
