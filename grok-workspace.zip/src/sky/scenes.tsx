import { STAR_POS, heartPoints } from "@/sky/content";
import { useEffect, useState } from "react";

const BASE = 430;

const LEFT = [
  { x: 18, w: 54, h: 130, seed: 1, antenna: false },
  { x: 78, w: 42, h: 190, seed: 2, antenna: false },
  { x: 126, w: 70, h: 150, seed: 3, antenna: false },
  { x: 202, w: 26, h: 230, seed: 4, antenna: true },
  { x: 234, w: 84, h: 110, seed: 5, antenna: false },
  { x: 324, w: 40, h: 78, seed: 6, antenna: false },
];

const RIGHT = [
  { x: 850, w: 48, h: 86, seed: 7, antenna: false },
  { x: 906, w: 72, h: 170, seed: 8, antenna: false },
  { x: 986, w: 30, h: 236, seed: 9, antenna: true },
  { x: 1022, w: 58, h: 142, seed: 10, antenna: false },
  { x: 1088, w: 44, h: 198, seed: 11, antenna: false },
  { x: 1140, w: 46, h: 120, seed: 12, antenna: false },
];

function Windows({
  x,
  y,
  w,
  h,
  seed,
}: {
  x: number;
  y: number;
  w: number;
  h: number;
  seed: number;
}) {
  const nodes = [];
  let n = 0;
  for (let yy = y + 14; yy < y + h - 12; yy += 18) {
    for (let xx = x + 9; xx < x + w - 9; xx += 16) {
      const kind = (n * 3 + seed) % 5;
      const wink = (n + seed) % 9 === 0;
      const cls =
        kind === 0 ? "win dim" : kind === 2 ? "win rose" : wink ? "win wink" : "win";
      nodes.push(<rect key={`${seed}-${n}`} className={cls} x={xx} y={yy} width="5" height="7" rx="0.8" />);
      n += 1;
    }
  }
  return nodes;
}

export function Panorama({ motionOn }: { motionOn: boolean }) {
  return (
    <svg
      className="panorama"
      viewBox="0 0 1200 560"
      role="img"
      aria-label="Céu noturno entre duas cidades distantes, com duas estrelas ligadas por um fio de luz"
    >
      <defs>
        <linearGradient id="horizon" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--color-night)" stopOpacity="0" />
          <stop offset="70%" stopColor="var(--color-dusk)" stopOpacity="0.2" />
          <stop offset="100%" stopColor="var(--color-night)" stopOpacity="0.95" />
        </linearGradient>
        <radialGradient id="glow-l" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--color-pearl)" stopOpacity="0.95" />
          <stop offset="40%" stopColor="var(--color-lilac)" stopOpacity="0.45" />
          <stop offset="100%" stopColor="var(--color-lilac)" stopOpacity="0" />
        </radialGradient>
        <filter id="soft-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2.2" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <rect width="1200" height="560" fill="url(#horizon)" />
      <path
        d="M390 168 Q600 96 830 214"
        fill="none"
        stroke="var(--color-lilac)"
        strokeWidth="2.2"
        filter="url(#soft-glow)"
        opacity="0.9"
      />
      {motionOn ? (
        <circle r="3.2" fill="var(--color-pearl)" filter="url(#soft-glow)">
          <animateMotion dur="11s" repeatCount="indefinite" path="M390 168 Q600 96 830 214" />
        </circle>
      ) : null}
      <circle cx="390" cy="168" r="34" fill="url(#glow-l)" />
      <circle cx="830" cy="214" r="34" fill="url(#glow-l)" />
      <circle cx="390" cy="168" r="3.4" fill="var(--color-pearl)" />
      <circle cx="830" cy="214" r="3.4" fill="var(--color-pearl)" />
      <path
        d="M1048 78c8 10 8 22 0 34 10-8 22-8 34 0-10-8-10-22 0-34-8 10-22 10-34 0z"
        fill="var(--color-pearl)"
        opacity="0.85"
      />
      {LEFT.map((b) => {
        const y = BASE - b.h;
        return (
          <g key={b.seed}>
            <rect
              x={b.x}
              y={y}
              width={b.w}
              height={b.h}
              rx="2"
              fill="color-mix(in oklab, var(--color-dusk) 72%, black)"
              stroke="color-mix(in oklab, var(--color-lilac) 38%, transparent)"
            />
            {b.antenna ? (
              <line
                x1={b.x + b.w / 2}
                y1={y}
                x2={b.x + b.w / 2}
                y2={y - 22}
                stroke="var(--color-pearl)"
                strokeOpacity="0.45"
              />
            ) : null}
            {Windows({ x: b.x, y, w: b.w, h: b.h, seed: b.seed })}
          </g>
        );
      })}
      {RIGHT.map((b) => {
        const y = BASE - b.h;
        return (
          <g key={b.seed}>
            <rect
              x={b.x}
              y={y}
              width={b.w}
              height={b.h}
              rx="2"
              fill="color-mix(in oklab, var(--color-dusk) 72%, black)"
              stroke="color-mix(in oklab, var(--color-lilac) 38%, transparent)"
            />
            {b.antenna ? (
              <line
                x1={b.x + b.w / 2}
                y1={y}
                x2={b.x + b.w / 2}
                y2={y - 26}
                stroke="var(--color-pearl)"
                strokeOpacity="0.45"
              />
            ) : null}
            {Windows({ x: b.x, y, w: b.w, h: b.h, seed: b.seed })}
          </g>
        );
      })}
    </svg>
  );
}

const LINKS: [number, number][] = [
  [0, 1],
  [1, 2],
  [2, 3],
  [3, 4],
  [1, 3],
];

export function Constellation({
  active,
  onPick,
}: {
  active: number | null;
  onPick: (index: number) => void;
}) {
  return (
    <div className="constellation">
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        {LINKS.map(([a, b]) => (
          <line
            key={`${a}-${b}`}
            x1={STAR_POS[a].x}
            y1={STAR_POS[a].y}
            x2={STAR_POS[b].x}
            y2={STAR_POS[b].y}
            className="const-line"
            vectorEffect="non-scaling-stroke"
          />
        ))}
      </svg>
      {STAR_POS.map((pos, index) => (
        <button
          key={pos.x}
          type="button"
          className={`star-btn ${active === index ? "is-on" : ""} delay-${index}`}
          style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
          onClick={() => onPick(index)}
          aria-pressed={active === index}
        >
          <span className="star-core" />
          <span className="sr-only">Estrela {index + 1}</span>
        </button>
      ))}
    </div>
  );
}

const BURST = Array.from({ length: 16 }, (_, i) => {
  const angle = (i / 16) * Math.PI * 2;
  const dist = i % 2 === 0 ? 78 : 118;
  return { dx: Math.cos(angle) * dist, dy: Math.sin(angle) * dist * 0.72 };
});

export function TwoSkies({
  litKey,
  left,
  right,
  motionOn,
}: {
  litKey: number;
  left: string;
  right: string;
  motionOn: boolean;
}) {
  return (
    <div className={`two-skies ${litKey > 0 ? "is-lit" : ""} ${motionOn ? "is-live" : ""}`}>
      <div className="mini-sky">
        <span className="pulse-star" />
        <span className="mini-label">{left}</span>
      </div>
      <div className="bond" aria-hidden="true" />
      <div className="mini-sky">
        <span className="pulse-star delay" />
        <span className="mini-label">{right}</span>
      </div>
      {litKey > 0 ? (
        <div className="center-star" key={litKey} aria-hidden="true">
          {BURST.map((bit, i) => (
            <i
              key={i}
              style={{
                ["--dx" as string]: `${bit.dx}px`,
                ["--dy" as string]: `${bit.dy}px`,
              }}
            />
          ))}
        </div>
      ) : null}
    </div>
  );
}

export function NightMap({
  mine,
  theirs,
  onMine,
  onTheirs,
}: {
  mine: string;
  theirs: string;
  onMine: () => void;
  onTheirs: () => void;
}) {
  return (
    <div className="night-map">
      <svg viewBox="0 0 800 360" role="img" aria-label="Mapa noturno simbólico com dois pontos ligados por estrelas">
        <path
          d="M70 150 C 120 70, 230 60, 280 140 C 320 210, 250 280, 150 260 C 70 244, 30 200, 70 150 Z"
          className="land"
        />
        <path
          d="M500 120 C 580 50, 720 70, 740 160 C 760 250, 650 300, 560 250 C 490 214, 450 180, 500 120 Z"
          className="land"
        />
        <path
          d="M210 170 C 320 120, 430 210, 590 150"
          className="map-road"
          fill="none"
        />
        {[280, 360, 450, 520].map((x, i) => (
          <circle key={x} cx={x} cy={150 + (i % 2 === 0 ? -18 : 22)} r="2.2" className="map-dot" />
        ))}
      </svg>
      <button type="button" className="map-point left" onClick={onMine}>
        <span className="star-core" />
        <span>{mine}</span>
      </button>
      <button type="button" className="map-point right" onClick={onTheirs}>
        <span className="star-core" />
        <span>{theirs}</span>
      </button>
    </div>
  );
}

const HEART = heartPoints(40);

export function HeartSky({ show }: { show: boolean }) {
  const [formed, setFormed] = useState(false);
  useEffect(() => {
    if (!show) {
      setFormed(false);
      return;
    }
    const id = requestAnimationFrame(() => setFormed(true));
    return () => cancelAnimationFrame(id);
  }, [show]);
  if (!show) return null;
  return (
    <div className="heart-sky" aria-hidden="true">
      {HEART.map((point, i) => {
        const sx = Math.cos(i * 2.17) * 130;
        const sy = Math.sin(i * 1.63) * 90;
        const x = formed ? point.x * 7.2 : sx;
        const y = formed ? point.y * 7.2 : sy;
        return (
          <span
            key={i}
            className={i % 6 === 0 ? "heart-star bright" : "heart-star"}
            style={{
              transform: `translate(${x}px, ${y}px)`,
              transitionDelay: `${i * 16}ms`,
            }}
          />
        );
      })}
    </div>
  );
}

export function EnvelopeGraphic({ open }: { open: boolean }) {
  return (
    <span className={`env ${open ? "is-open" : ""}`} aria-hidden="true">
      <span className="env-pocket" />
      <span className="env-flap" />
      <span className="env-seal">
        <svg viewBox="0 0 24 24">
          <path d="M12 1.2 14.7 8.4 22.2 9l-5.4 4.8 1.6 7.2L12 17.4 5.6 21l1.6-7.2L1.8 9l7.5-.6L12 1.2Z" />
        </svg>
      </span>
    </span>
  );
}

export function GlassBox({ open }: { open: boolean }) {
  return (
    <span className={`glass-box ${open ? "is-open" : ""}`} aria-hidden="true">
      <span className="glass-lid" />
      <span className="box-star" />
    </span>
  );
}
