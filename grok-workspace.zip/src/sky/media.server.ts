import { getSql } from "@/lib/db";

const AUDIO = new Set([
  "audio/mpeg",
  "audio/mp3",
  "audio/mp4",
  "audio/aac",
  "audio/ogg",
  "audio/wav",
  "audio/x-wav",
  "audio/webm",
]);

const IMAGES = new Set(["image/jpeg", "image/png", "image/webp"]);

export async function readMedia(key: string): Promise<{ mime: string; bytes: Uint8Array } | null> {
  if (key !== "music" && key !== "photo1" && key !== "photo2") return null;
  const sql = await getSql();
  const rows = await sql.query<{ mime: string; data: string }>(
    "select mime, data from sky_media where key = $1",
    [key],
  );
  const row = rows[0];
  if (!row?.data) return null;
  const allowed = key === "music" ? AUDIO : IMAGES;
  if (!allowed.has(row.mime)) return null;
  return { mime: row.mime, bytes: Uint8Array.from(Buffer.from(row.data, "base64")) };
}
