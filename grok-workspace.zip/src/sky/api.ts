import { createServerFn } from "@tanstack/react-start";
import { getSql, type Sql } from "@/lib/db";
import {
  freshState,
  sanitize,
  type SkySnapshot,
} from "@/sky/content";

type MediaKey = "music" | "photo1" | "photo2";

const AUDIO = new Set([
  "audio/mpeg",
  "audio/mp3",
  "audio/mp4",
  "audio/aac",
  "audio/ogg",
  "audio/wav",
  "audio/x-wav",
  "audio/webm",
]);

const IMAGES = new Set(["image/jpeg", "image/png", "image/webp"]);

function stamp(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  if (typeof value === "string" && value) {
    const parsed = new Date(value);
    if (!Number.isNaN(parsed.getTime())) return parsed.toISOString();
  }
  return new Date().toISOString();
}

async function ensureDocument(sql: Sql) {
  const { DEFAULTS } = await import("@/sky/content");
  await sql.query(
    `insert into sky_document (id, payload)
     values (1, $1)
     on conflict (id) do nothing`,
    [JSON.stringify(DEFAULTS)],
  );
}

async function readState(sql: Sql): Promise<SkySnapshot> {
  await ensureDocument(sql);
  const docs = await sql.query<{ payload: string; revision: number; updated_at: unknown }>(
    "select payload, revision, updated_at from sky_document where id = 1",
  );
  const doc = docs[0];
  if (!doc) return freshState();
  let parsed: unknown = {};
  try {
    parsed = JSON.parse(doc.payload);
  } catch {
    parsed = {};
  }
  const media = await sql.query<{ key: string; updated_at: unknown }>(
    "select key, updated_at from sky_media",
  );
  const at = (key: MediaKey) => {
    const row = media.find((item) => item.key === key);
    return row ? stamp(row.updated_at) : null;
  };
  return {
    content: sanitize(parsed),
    revision: Number(doc.revision) || 1,
    updatedAt: stamp(doc.updated_at),
    musicAt: at("music"),
    photo1At: at("photo1"),
    photo2At: at("photo2"),
  };
}

async function authorize(password: string): Promise<string | null> {
  const { passwordMatches } = await import("@/sky/guard.server");
  if (passwordMatches(password)) return null;
  await new Promise((resolve) => setTimeout(resolve, 450));
  return "Senha incorreta.";
}

function readPassword(input: unknown): string | null {
  if (!input || typeof input !== "object") return null;
  const password = (input as { password?: unknown }).password;
  if (typeof password !== "string" || password.length > 200) return null;
  return password;
}

export const getSky = createServerFn({ method: "GET" }).handler(async (): Promise<SkySnapshot> => {
  const sql = await getSql();
  return readState(sql);
});

export const checkAdmin = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const password = readPassword(input);
    if (password === null) throw new Error("Senha inválida.");
    return { password };
  })
  .handler(async ({ data }) => {
    const error = await authorize(data.password);
    if (error) return { ok: false as const, error };
    return { ok: true as const };
  });

export const saveSky = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const password = readPassword(input);
    if (password === null) throw new Error("Senha inválida.");
    const content = sanitize((input as { content?: unknown }).content);
    return { password, content };
  })
  .handler(async ({ data }) => {
    const error = await authorize(data.password);
    if (error) return { ok: false as const, error };
    const sql = await getSql();
    await ensureDocument(sql);
    await sql.query(
      `update sky_document
       set payload = $1, revision = revision + 1, updated_at = now()
       where id = 1`,
      [JSON.stringify(data.content)],
    );
    const snapshot = await readState(sql);
    return { ok: true as const, ...snapshot };
  });

function mediaKey(value: unknown): MediaKey | null {
  if (value === "music" || value === "photo1" || value === "photo2") return value;
  return null;
}

export const saveMedia = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const password = readPassword(input);
    if (password === null) throw new Error("Senha inválida.");
    const record = input as { key?: unknown; mime?: unknown; data?: unknown };
    const key = mediaKey(record.key);
    if (!key) throw new Error("Arquivo inválido.");
    const mime = typeof record.mime === "string" ? record.mime.slice(0, 120) : "";
    const data = typeof record.data === "string" ? record.data : "";
    return { password, key, mime, data };
  })
  .handler(async ({ data }) => {
    const error = await authorize(data.password);
    if (error) return { ok: false as const, error };
    const sql = await getSql();
    await ensureDocument(sql);

    if (!data.data) {
      await sql.query("delete from sky_media where key = $1", [data.key]);
    } else {
      const allowed = data.key === "music" ? AUDIO : IMAGES;
      if (!allowed.has(data.mime)) {
        return { ok: false as const, error: "Esse formato não pode entrar no céu." };
      }
      const approxBytes = Math.floor((data.data.length * 3) / 4);
      const limit = data.key === "music" ? 2_000_000 : 700_000;
      if (approxBytes > limit || data.data.length > (data.key === "music" ? 3_000_000 : 1_200_000)) {
        return {
          ok: false as const,
          error: data.key === "music" ? "O áudio precisa ter até 2 MB." : "A foto precisa ter até 700 KB.",
        };
      }
      await sql.query(
        `insert into sky_media (key, mime, data, updated_at)
         values ($1, $2, $3, now())
         on conflict (key) do update
         set mime = excluded.mime, data = excluded.data, updated_at = now()`,
        [data.key, data.mime, data.data],
      );
    }

    await sql.query(
      "update sky_document set revision = revision + 1, updated_at = now() where id = 1",
    );
    const snapshot = await readState(sql);
    return { ok: true as const, ...snapshot };
  });

