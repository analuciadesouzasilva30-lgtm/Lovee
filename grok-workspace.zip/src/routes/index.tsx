import { createFileRoute } from "@tanstack/react-router";
import { getSky } from "@/sky/api";
import { freshState } from "@/sky/content";
import { Experience } from "@/sky/experience";

export const Route = createFileRoute("/")({
  loader: async () => {
    try {
      return await getSky();
    } catch (error) {
      console.error(error);
      return freshState();
    }
  },
  component: Home,
});

function Home() {
  const data = Route.useLoaderData();
  return <Experience initial={data} />;
}
