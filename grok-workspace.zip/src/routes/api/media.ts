import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/media")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const key = url.searchParams.get("key") ?? "";
        try {
          const { readMedia } = await import("@/sky/media.server");
          const media = await readMedia(key);
          if (!media) {
            return new Response("Não encontrado", { status: 404 });
          }
          const bytes = Uint8Array.from(media.bytes);
          return new Response(bytes, {
            status: 200,
            headers: {
              "content-type": media.mime,
              "cache-control": url.searchParams.get("v")
                ? "public, max-age=31536000, immutable"
                : "no-store",
              "x-content-type-options": "nosniff",
            },
          });
        } catch (error) {
          console.error(error);
          return new Response("Não foi possível abrir o arquivo", { status: 500 });
        }
      },
    },
  },
});
